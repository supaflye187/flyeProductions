(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.Bitmap1 = function() {
	this.initialize(img.Bitmap1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,258,96);


(lib.Image_01 = function() {
	this.initialize(img.Image_01);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,300,393);


(lib.Image_02 = function() {
	this.initialize(img.Image_02);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,300,376);


(lib.Image_03 = function() {
	this.initialize(img.Image_03);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,300,376);


(lib.Image_04 = function() {
	this.initialize(img.Image_04);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,300,376);// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.txt_qualityCare = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AsmE4QgdgNgVgVQgUgVgLgdQgMgdAAghQAAghAMgdQAMgdAUgVQAWgVAcgMQAdgMAiAAQAWAAAVAFQAUAGASAKQARAKAOAOQAOAOAKARIhAAoQgKgUgSgMQgSgMgaAAQgSAAgPAGQgPAHgLAMQgLALgGAQQgGAQAAARQAAASAFAPQAHAQAKALQAMAMAOAGQAPAHATAAQAbAAATgOQASgOAKgWIBEAlQgKASgPAQQgNAQgTAMQgSALgVAHQgWAGgYAAQgjAAgdgMgAgDFAIAAkzIDTAAIAABEIiLAAIAAAzICLAAIAABEIiLAAIAAA0ICLAAIAABEgAhqFAIgrhcIg6AAIAABcIhJAAIAAkzICEAAQAcAAAVAJQAVAIAPAOQAPAOAIAUQAHATAAAWQAAAdgNAYQgNAXgYAOIA6BvgAjPChIA1AAQAYAAALgLQALgNAAgRQABgTgMgKQgLgLgYAAIg1AAgAl1FAIgQguIh1AAIgQAuIhKAAIBykzIBGAAIBxEzgAmbDSIgkhnIgkBnIBIAAgAnhgQQgYgIgPgQQgRgQgIgXQgJgXAAgeIAAi6IBKAAIAAC6QAAAZAOAOQANAOAXAAQAVAAAPgOQANgOAAgZIAAi6IBKAAIAAC6QABAegJAXQgJAXgQAQQgQAQgXAIQgXAIgcAAQgdAAgWgIgAskgUQgdgMgUgWQgWgVgMgcQgMgdAAghQAAghAMgcQAMgdAWgVQAUgWAdgMQAdgNAhAAQAgAAAdANQAcAMAWAWQAVAVAMAdQANAcAAAhQAAAbgKAZQgKAYgRAVIAsA4IhRAAIgMgPQgRAJgSAFQgSAFgSAAQghAAgdgMgAsJj3QgPAIgLAMQgMAMgGAQQgHAQAAASQAAASAHAQQAGAQAMAMQALAMAPAHQAQAHATAAQAOAAAOgFIhEhXIBTAAIAhAsQAKgTAAgVQAAgSgHgQQgGgQgMgMQgMgMgPgIQgRgHgRAAQgTAAgQAHgALVgMIAAiAIhkiyIBQAAIA6BuIA6huIBPAAIhlCzIAAB/gAHHgMIAAjvIhTAAIAAhDIDtAAIAABDIhSAAIAADvgAEJgMIAAkyIBKAAIAAEygAAagMIAAkyIBJAAIAADsICFAAIAABGgAhCgMIgQgtIh1AAIgQAtIhKAAIBxkyIBHAAIBwEygAhoh5IgkhnIgkBnIBIAAg");
	this.shape.setTransform(-25.65,-17.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.txt_qualityCare, new cjs.Rectangle(-115.6,-49.4,180,64.8), null);


(lib.txt_earlyDetection = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AKaE6QgdgMgWgWQgVgWgNgdQgMgeAAghQAAgiAMgdQANgdAVgWQAWgWAdgNQAdgNAiAAQAhAAAeANQAdANAWAWQAWAWAMAdQANAdAAAiQAAAhgNAeQgMAdgWAWQgWAWgdAMQgdANgiAAQgiAAgdgNgAK3BVQgQAHgLAMQgLAMgGAQQgHAQAAASQAAASAHAQQAGAPALAMQALAMAQAHQAQAHASAAQATAAAPgHQAQgHALgMQAMgMAGgPQAGgQAAgSQAAgSgGgQQgGgQgMgMQgMgMgPgHQgQgHgSAAQgSAAgQAHgAggE6QgegMgVgWQgVgWgLgdQgMgeAAghQAAgjAMgdQAMgeAWgVQAVgWAegMQAdgNAiAAQAXAAAUAGQAVAGASAKQASAKAPAOQAOAPALARIhCAqQgLgVgSgNQgTgMgaAAQgTAAgOAHQgQAHgLAMQgLAMgGAQQgGAQAAASQAAASAGAQQAGAPALAMQALAMAPAHQAPAHATAAQAcAAATgPQATgOAKgXIBFAmQgKATgPAQQgOAQgSAMQgTAMgWAHQgWAGgZAAQgjAAgegNgARYFDIh8jGIAADGIhHAAIAAk6IBOAAIB2C8IAAi8IBHAAIAAE6gAHRFDIAAk6IBMAAIAAE6gAEWFDIAAj1IhVAAIAAhFIDyAAIAABFIhUAAIAAD1gAlwFDIAAk6IDZAAIAABGIiOAAIAAAzICOAAIAABGIiOAAIAAA1ICOAAIAABGgAoqFDIAAj1IhVAAIAAhFIDyAAIAABFIhUAAIAAD1gAtyFDIAAk6IDZAAIAABGIiOAAIAAAzICOAAIAABGIiOAAIAAA1ICOAAIAABGgAyfFDIAAk6IBvAAQAkAAAeAMQAfAMAVAVQAWAVALAdQAMAcAAAiQAAAhgMAdQgMAdgWAVQgVAVgeAMQgeAMgjAAgAxVD9IAjAAQAUAAARgHQAQgHAMgMQAMgLAGgQQAHgQAAgSQAAgTgGgQQgHgPgLgMQgMgMgRgHQgRgGgWAAIghAAgAhIgMIAAiDIhmi3IBRAAIA8BxIA6hxIBRAAIhnC4IAACCgAlmgMIAAk6IBLAAIAADyICJAAIAABIgAnLgMIgsheIg7AAIAABeIhLAAIAAk6ICHAAQAcAAAWAJQAWAJAPAOQAPAPAIATQAIAUAAAWQAAAegOAZQgNAYgYAOIA7BxgAoyiuIA2AAQAZAAALgMQALgMAAgSQAAgTgLgLQgMgLgYAAIg2AAgArXgMIgQgvIh4AAIgRAvIhLAAIB0k6IBIAAIB0E6gAr+h8IglhpIglBpIBKAAgAyfgMIAAk6IDYAAIAABGIiOAAIAAA0ICOAAIAABFIiOAAIAAA2ICOAAIAABFg");
	this.shape.setTransform(4.075,-17.125);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.txt_earlyDetection, new cjs.Rectangle(-114.3,-49.8,236.8,65.39999999999999), null);


(lib.txt_cancerHatesUs = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("An+HrQgTgFgRgHQgPgJgNgKQgNgMgLgNIA9gwQANATATALQARAMAaAAQASAAAKgIQAKgIAAgMQgBgIgEgEQgDgFgIgEIgTgHIg9gQQgQgFgOgKQgNgJgKgQQgIgPAAgXQAAgTAIgRQAJgRAOgNQAOgMAUgHQAVgHAXAAQAVAAARAEQAQADAPAHQAOAHANAKIAYAWIg6AtQgKgRgQgIQgPgKgWAAQgTAAgIAIQgJAJAAAJQAAAIAFAEQAEAFAIADIBOAVQARAFAOAKQAOALAKAPQAIAPABAZQAAAVgJASQgIASgQANQgPANgVAHQgVAIgZAAQgYgBgVgEgAsdHoQgWgJgQgQQgQgPgIgXQgJgWAAgdIAAi2IBJAAIAAC2QAAAZANAOQANANAWAAQAWAAANgNQANgOAAgZIAAi2IBJAAIAAC2QABAdgKAWQgIAXgPAPQgQAQgXAJQgWAHgbABQgdgBgWgHgAEICYQgUgEgQgJQgQgHgNgMQgNgLgLgNIA+gxQANAVASAKQASAMAZAAQATAAAKgIQAJgIAAgMQAAgHgEgGQgEgEgHgEIgTgHIg+gQQgQgFgOgKQgNgJgJgPQgJgPAAgXQAAgUAJgRQAIgQAOgMQAPgNATgHQAVgHAYAAQAUAAASAEQAQADAOAHQAPAHAMAKIAZAXIg6AtQgLgRgPgJQgPgKgXAAQgSAAgJAJQgIAHgBALQABAGAEAFQAFAFAHADIBPAUQARAGAOAKQAOAJAJAQQAJAPAAAYQAAAWgIASQgJARgQANQgOAOgWAHQgVAIgYgBQgZAAgUgEgAg9CZIAAkrIDOAAIAABDIiIAAIAAAxICIAAIAABBIiIAAIAAAzICIAAIAABDgAjyCZIAAjoIhRAAIAAhDIDnAAIAABDIhQAAIAADogAl8CZIgPgtIhzAAIgQAtIhIAAIBvkrIBFAAIBvErgAmiAuIgjhkIgjBkIBGAAgAq5CZIAAhzIhiAAIAABzIhIAAIAAkrIBIAAIAABxIBiAAIAAhxIBHAAIAAErgACCjHQgcgMgUgVQgUgUgMgdQgKgcgBgfQAAgiAMgcQALgcAVgUQAUgVAcgMQAdgLAhAAQAVgBAVAGQATAGARAJQASAKANAOQAOANAKARIg/AnQgKgUgSgLQgRgMgZAAQgRAAgPAGQgPAHgLALQgKAMgHAPQgFAPgBASQABAQAFAPQAGAPALALQALAMAOAGQAPAHARAAQAcAAARgOQATgOAJgUIBCAiQgKATgOAQQgNAPgRALQgSAMgVAGQgVAGgYAAQgjAAgcgMgAsPjHQgcgMgUgVQgVgUgKgdQgLgcAAgfQAAgiALgcQALgcAVgUQAVgVAcgMQAcgLAhAAQAWgBATAGQAUAGARAJQARAKAPAOQANANAKARIg+AnQgLgUgSgLQgRgMgYAAQgTAAgPAGQgOAHgLALQgKAMgHAPQgFAPAAASQAAAQAFAPQAGAPAKALQALAMAPAGQAOAHATAAQAaAAATgOQASgOAJgUIBCAiQgKATgOAQQgNAPgSALQgRAMgVAGQgVAGgYAAQgiAAgdgMgAMci/IgqhaIg5AAIAABaIhHAAIAAksICBAAQAbAAAVAJQAVAIAOAOQAPAOAHASQAHAUAAAVQAAAcgNAXQgNAXgWANIA3BtgAK5laIA0AAQAYAAALgLQAKgMAAgRQAAgSgLgKQgLgLgXAAIg0AAgAFyi/IAAksIDPAAIAABDIiHAAIAAAxICHAAIAABCIiHAAIAAAzICHAAIAABDgAhFi/Ih2i8IAAC8IhEAAIAAksIBLAAIBwC0IAAi0IBEAAIAAEsgAlji/IgPgtIhzAAIgQAtIhIAAIBvksIBFAAIBuEsgAmJkqIgjhlIgjBlIBGAAg");
	this.shape.setTransform(-27.15,-0.7);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.txt_cancerHatesUs, new cjs.Rectangle(-114.6,-50.2,174.89999999999998,99.1), null);


(lib.txt_cancerHatesFighters = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgkCdQgVgFgRgIQgRgJgNgLQgOgMgLgNIBBgzQANAUATAMQATAMAaAAQATAAAKgIQAKgIAAgNQAAgIgEgGQgEgFgIgEIgUgHIgcgGIgjgLQgRgFgPgKQgOgKgJgPQgJgQAAgZQAAgUAJgSQAIgRAPgNQAPgNAVgIQAWgGAYAAQAVgBASAEQASADAPAIQAOAHANAKIAaAZIg8AuQgLgSgQgJQgQgKgYAAQgSABgJAIQgJAJAAAKQAAAIAEAEQAFAFAIADIATAGIAaAHIAkAJQASAGAPALQAPAJAJAQQAKAQAAAaQAAAWgJATQgJATgQANQgQAPgWAHQgWAIgaAAQgZAAgVgFg");
	this.shape.setTransform(75.575,32.95);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAvCdIgshfIg6AAIAABfIhKAAIAAk5ICGAAQAcAAAWAJQAWAIAPAPQAPAOAIAUQAHAUAAAWQAAAegNAYQgOAYgXANIA6BygAg3gEIA3AAQAXAAALgNQAMgMAAgRQAAgUgMgKQgLgMgXAAIg3AAg");
	this.shape_1.setTransform(49.975,33);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AhrCdIAAk5IDXAAIAABGIiNAAIAAAzICNAAIAABFIiNAAIAAA2ICNAAIAABFg");
	this.shape_2.setTransform(22.725,33);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgjCdIAAj0IhVAAIAAhFIDxAAIAABFIhUAAIAAD0g");
	this.shape_3.setTransform(-3.375,33);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAzCdIAAh5IhlAAIAAB5IhMAAIAAk5IBMAAIAAB3IBlAAIAAh3IBLAAIAAE5g");
	this.shape_4.setTransform(-31.25,33);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("Ag9CVQgfgNgVgWQgWgWgLgeQgLgdAAghQAAghAMgdQAMgeAVgVQAVgWAegMQAegNAiAAQAuAAAhARQAhARAWAdIg+AsQgLgRgSgKQgSgJgYAAQgRAAgQAHQgQAHgMAMQgMAMgHAQQgHARAAASQAAAVAHAQQAGAQAMAMQAMAMAQAHQARAGASAAQAbAAATgNQASgNAIgXIhWAAIAAhFICnAAIAAAjQAAAfgKAcQgLAcgUAVQgUAWgdAMQgcAMgiAAQglAAgegMg");
	this.shape_5.setTransform(-62.775,32.975);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AglCdIAAk5IBLAAIAAE5g");
	this.shape_6.setTransform(-85.425,33);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AhrCdIAAk5IDXAAIAABHIiMAAIAAA4ICMAAIAABEIiMAAIAAB2g");
	this.shape_7.setTransform(-103.575,33);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgkCdQgVgFgRgIQgRgIgNgMQgOgMgLgNIBBg0QANAWATALQATAMAaAAQATAAAKgJQAKgHAAgNQAAgIgEgGQgEgEgIgFIgUgGIgcgHIgjgKQgRgGgPgKQgOgJgJgQQgJgQAAgYQAAgVAJgSQAIgRAPgNQAPgNAVgHQAWgIAYABQAVAAASADQASADAPAIQAOAHANAKIAaAYIg8AvQgLgSgQgJQgQgKgYAAQgSAAgJAJQgJAIAAALQAAAHAEAFQAFAFAIADIATAGIAaAHIAkAJQASAGAPALQAPAJAJAQQAKAQAAAaQAAAXgJASQgJATgQAOQgQAOgWAHQgWAIgaAAQgZgBgVgEg");
	this.shape_8.setTransform(7.075,-0.6);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AhrCdIAAk5IDXAAIAABGIiNAAIAAAzICNAAIAABFIiNAAIAAA1ICNAAIAABGg");
	this.shape_9.setTransform(-17.625,-0.55);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgjCdIAAjzIhVAAIAAhGIDxAAIAABGIhUAAIAADzg");
	this.shape_10.setTransform(-43.725,-0.55);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("ABMCdIgQgvIh3AAIgRAvIhLAAIB0k5IBHAAIB0E5gAAlAsIglhnIgkBnIBJAAg");
	this.shape_11.setTransform(-72.175,-0.55);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AAzCdIAAh5IhlAAIAAB5IhMAAIAAk5IBMAAIAAB3IBlAAIAAh3IBMAAIAAE5g");
	this.shape_12.setTransform(-101.7,-0.55);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AAvCdIgsheIg6AAIAABeIhKAAIAAk5ICGAAQAcAAAWAIQAWAKAPAOQAPAPAIATQAHAUAAAWQAAAegNAXQgOAZgXANIA6BygAg3gEIA3AAQAXAAALgMQAMgMAAgTQAAgSgMgMQgLgLgXABIg3AAg");
	this.shape_13.setTransform(48.525,-34.1);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AhrCdIAAk5IDXAAIAABGIiNAAIAAA0ICNAAIAABEIiNAAIAAA1ICNAAIAABGg");
	this.shape_14.setTransform(21.275,-34.1);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("Ag5CVQgegNgVgWQgVgVgLgeQgMgdAAgiQAAghAMgeQAMgdAWgWQAVgVAegNQAdgMAiAAQAXAAAUAGQAVAFASAKQASAKAPAPQAOAOALARIhCAqQgLgVgSgMQgTgMgaAAQgSAAgPAGQgQAHgLAMQgLAMgGAQQgGAQAAARQAAASAGAQQAGAQALAMQALALAPAHQAQAHASAAQAcAAATgOQATgPAKgWIBFAlQgKATgPARQgOAQgSAMQgTAMgWAGQgWAGgZAAQgjAAgegMg");
	this.shape_15.setTransform(-7.125,-34.125);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AA9CdIh6jFIAADFIhIAAIAAk5IBOAAIB2C7IAAi7IBHAAIAAE5g");
	this.shape_16.setTransform(-38.725,-34.1);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("ABMCdIgQgvIh3AAIgRAvIhLAAIB0k5IBHAAIB0E5gAAlAtIglhoIgkBoIBJAAg");
	this.shape_17.setTransform(-68.975,-34.1);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("Ag5CVQgegNgVgWQgVgVgLgeQgMgdAAgiQAAghAMgeQAMgdAWgWQAVgVAegNQAdgMAiAAQAXAAAUAGQAVAFASAKQASAKAPAPQAOAOALARIhCAqQgLgVgSgMQgTgMgaAAQgSAAgPAGQgQAHgLAMQgLAMgGAQQgGAQAAARQAAASAGAQQAGAQALAMQALALAPAHQAQAHASAAQAcAAATgOQATgPAKgWIBFAlQgKATgPARQgOAQgSAMQgTAMgWAGQgWAGgZAAQgjAAgegMg");
	this.shape_18.setTransform(-99.775,-34.125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.txt_cancerHatesFighters, new cjs.Rectangle(-118.7,-63.8,237.5,127.69999999999999), null);


(lib.txt_advancedTreatment = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AQ2FBIAAjpIhRAAIAAhCIDnAAIAABCIhQAAIAADpgAOGFBIh2i8IAAC8IhEAAIAAkrIBKAAIBxC0IAAi0IBEAAIAAErgAHAFBIAAkrIDPAAIAABCIiHAAIAAAyICHAAIAABCIiHAAIAAAzICHAAIAABCgAFAFBIAAi+IhPBrIhOhqIAAC9IhGAAIAAkrIBEAAIBRBwIBThwIBBAAIAAErgAhdFBIAAjpIhRAAIAAhCIDmAAIAABCIhPAAIAADpgAjiFBIgPgsIhzAAIgPAsIhJAAIBvkrIBFAAIBvErgAkHDWIgjhkIgkBkIBHAAgAqkFBIAAkrIDPAAIAABCIiHAAIAAAyICHAAIAABCIiHAAIAAAzICHAAIAABCgAsSFBIgrhaIg4AAIAABaIhHAAIAAkrICBAAQAbAAAVAIQAVAIAOAOQAOAOAIATQAHATAAAVQAAAcgNAYQgNAXgWANIA3BsgAt1CnIA0AAQAXAAALgMQALgMAAgRQAAgSgLgKQgLgLgXAAIg0AAgAxxFBIAAjpIhSAAIAAhCIDoAAIAABCIhRAAIAADpgAE+gZQgcgMgUgVQgVgUgLgcQgLgcAAggQAAghAMgcQALgcAVgVQAUgVAcgLQAcgMAiAAQAVAAAUAFQAUAGARAJQARAKAOAOQAOANAKARIg/AnQgKgUgSgLQgRgMgZAAQgSAAgPAGQgPAHgKALQgLAMgGAPQgGAPAAASQAAARAGAPQAGAPAKALQALALAPAHQAOAGASAAQAbAAASgNQASgOAKgVIBCAjQgKASgOAQQgNAPgSAMQgRALgVAGQgVAGgYAAQgjAAgcgMgAMpgRIAAkrIBrAAQAiAAAdALQAdAMAUAUQAVAUALAbQALAcAAAgQAAAggLAbQgMAcgVATQgUAUgdAMQgcALghAAgANxhUIAhAAQATAAAQgGQAQgGALgMQALgLAGgPQAGgPAAgRQAAgSgGgPQgFgPgLgMQgLgLgRgGQgQgHgVAAIgfAAgAIpgRIAAkrIDPAAIAABCIiIAAIAAAyICIAAIAABCIiIAAIAAAzICIAAIAABCgAB1gRIh1i8IAAC8IhEAAIAAkrIBKAAIBxC0IAAi0IBEAAIAAErgAiogRIgQgsIhyAAIgQAsIhIAAIBvkrIBFAAIBuErgAjOh8IgjhkIgjBkIBGAAgAoegRIhvkrIBLAAIBHDKIBHjKIBKAAIhvErgAuSgRIAAkrIBqAAQAjAAAdALQAcAMAVAUQAUAUAMAbQALAcAAAgQAAAggMAbQgLAcgVATQgUAUgdAMQgcALgiAAgAtLhUIAhAAQAUAAAQgGQAPgGAMgMQALgLAGgPQAGgPAAgRQAAgSgGgPQgGgPgLgMQgLgLgQgGQgQgHgVAAIggAAgAvxgRIgQgsIhyAAIgQAsIhIAAIBvkrIBFAAIBuErgAwXh8IgjhkIgjBkIBGAAg");
	this.shape.setTransform(8.075,-17.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.txt_advancedTreatment, new cjs.Rectangle(-114.7,-49.1,245.60000000000002,64.2), null);


(lib.safeCare_logo = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgKgPIAVAXIgTAIg");
	this.shape.setTransform(17.375,-7.575);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgPgGIAOgGQAMgFAEALQAFAKgMAFIgOAGg");
	this.shape_1.setTransform(24.1864,-11.9531);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgKgPIAVAXIgTAIg");
	this.shape_2.setTransform(-26.875,10.725);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AmpBfIFaiOIACgBIAJgEIAAAAIAIgDIABAAIAIgDIAMgGIACAAIAHgDIAEgCIAOgGIACAAIAFgDIACgBIAFgDIABAAIAIgDIAAAAIAKgEIANgFIBfgoIAEgCIDshhIA5CLIh0AwIgBAAIgBABIgBAAIiuBHIgDABIgxAUIgLAFIAAAAIgJADIAAABIgHADIgBAAIgGACIgCABIgFACIgCABIgFADIgCAAIgLAFIgCAAIgGADIgBABIgNAFIgBAAIgIAEIgBAAIg7AYIgDACIixBKIgBAAIgBABIhzAvgAlnC0QAWAKAWgJQAVgIABgUQABgGgDgGQgDgIgHgFQgIgEgTACIgOACQgFAAgCgEQgBgCACgEQABgDAFgCQAFgCAGAAQAFABAGAEIAKgTIgDgCQgSgIgSAIQgLAFgGAIQgGAKACAJIACAHQAEALAMADQAHABANgBIAOgCQAGAAABAEQAEAIgLAEQgNAGgNgJgAkbBEIAEBeIABADIAIgEIABAAIAFgCIABAAIACgBIAAAAIACgBIABAAIgBgPIAfgNIAKALIAUgIIhChIgAjfArIAjBUIAUgIIgNgfIAlgQIgIgTIglAQIgGgQIAlgPIgIgTgAiXANIALAdIABAAIAXA4IA5gYIgDgGIgFgNIglAQIgBgCIgEgJIgBgDIAAgBIAlgPIgCgGIAAAAIgGgNIglAPIgFgMIgBgBIAmgQIgIgSgAgHAWIAAAAIgBAEIAAAAIABAEIABABIABADIAIAVIACgBIAFgCIABAAIADgBIAEgCIgSgvgAAPAhIAFgCIABAAIADgCIAAgBIADgBIABAAIACgBIAAgBIgBgCIgCgFIgDgGIgBgBIgWgKgAgfAOIABACIAAAAIABADIAAAAIABAEIAAAAIAEAIIAJgFIADAAIABgBIAKgXIgSAHIgCABIgGADIAAAAgAgngDIgDABIgIACIgDACIABACIABAEIABACIABADIACAEIABABIAXgKIADgBIASgHIgWgIIgCgBIAAAAIgCABIgBAAgAAbgJIgZAJIAXAJIACgBIAEgBIACAAIABgBIALgFIAAAAIAIgCIgBgDIgBgCIgBgDIgBgCIgCgHgABdhZIgIAEQgLAIgFAMIgCAEQgCAHAAAFIAAAKIACAIIACADIAAACIABABIADAGIABABIAFAGIABABIAKAIQAQAHAUgEIADgCQAGgCAFgFIAGgEQALgNAAgQIgWgCIAAAEQgCAJgGAFIgGAEIAAAAIgHACQgHAAgGgCIgFgEIgFgFIgCgFIgCgIIAAgHIACgGQAEgIAIgEIAFgCQAKgBAHAFIABABIAAAAIACABIADgFIAAAAIAJgNQgMgKgPABIgEAAQgIAAgGADgAgBAAIgJgVIAAgBIgEgKIgFACIgBAAIgGADIgBAAIgDABIAAAAIABACIADAIIABADIABACIACABIACAAIATAKgAAXgdIgFACIgDABIgCABIgBAAIgBABIgBACIgIAVIAWgJIAAAAIAHgDIAAgBIgCgFIAAgBIgCgDIAAgBIgBgDIAAgBIgBgCgAgEg2IgCABIgDABIgJAEIAHASIABACIACAFIAAABIAIAVIAJgYIgBgCIgBgDIgBAAIgDgIIgGgQgACehzIAFBiIAUgJIgBgOIACAAIAdgNIAKALIAUgJIhChIgAEDibIgJACIgkAQIAjBUIAUgIIgLgaIAQgGIAVAUIABAAIABAAIAAAAIABAAIAGgCIABgBIAGgDIAHgDIgcgYIADgEQADgIgBgIIgCgKQgCgFgEgFIgCgBQgFgGgIgBIgJgBgAEiipIAjBVIA5gYIgHgTIgmAQIgGgPIAmgQIgIgSIgmAQIgFgPIAlgPIgIgTg");
	this.shape_3.setTransform(-1.575,0.15);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AhhBGQgbgMgXgUIAmgQIACABIACgDIACAAIgDAEIALAHIAIgSIAFgCIgMAUIALAGIABAAIAKgeIAGgDIgPAhIAMAFIAJgoIAIgCIgQAqIANADIAGgvIAIgDIgNAyIANADIABg2IAIgDIgJA5IAOAAIgEg5IAHgDIABAAIAIgEIAHgDIAGgCIABgBIAFgCIABgBIANgFIABAAIAHgDIABgBIAHgDIAmArIAJgJIgugiIAIgDIAmAkIAIgKIgtgbIAIgDIAlAdIAHgLIgpgTIAIgEIAhAWIAGgMIghgMIAGgDIAbAOIAEgMIgVgGIAFgCIAQAHQADgHAAgGIgDgBIACAAIACAAIAAgBIAmgQQgCArgWAlQgVAlgkAXQgNAJgPAGQghAOghAAQgjAAgjgPgAgeA8QgDADABAEQAAAEADACQADADADAAQAKgBgBgJQAAgEgDgDQgCgCgEAAQgEAAgDADgAg/A+QgBAKAJABQAGACADgFIgDgDQgDACgCAAQgFgBABgFQABgFAEABQADABABACIAEgBQgBgFgGgBIgDAAQgGAAgCAHgAgFA4IAKARIAEgBIADgUIgFABIgBANIgGgLgAAWAxIAHARIAEgBIgGgSgAAsAnIgGADIAJAQIAGgDQAIgEgEgJQgDgFgFAAIgFACgAgbAwIAOAAIgKg6gAgNAwIANgCIgPg5gAAAAtIANgDIgUg3gAAOAqIALgEIABgBIgag0gAAbAlIALgGIgfgxgABDAhIADADIAHgGIgDgDgAAnAfIALgHIgkgugAAzAYIAKgIIgogrgABfAWIADgDIgOgNIgDADQAEADgDAEIgBAAIAEADIAAgBQAAAAABgBQAAAAAAgBQABAAAAgBQAAgBgBAAgAA+APIAJgJIgrgmgABqACIgCACIACAEIAEgEQAEgGgIgGQgDgCgDAAQgEABgBACQgEAFAFADQAGAEADgFQAAAAAAAAQABgBAAAAQAAgBAAAAQAAgBgBAAQADACgCADg");
	this.shape_4.setTransform(1.325,9.7252);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("Ah1gIQAdgsAxgUQAvgUA1AKQAyAKAmAkIgmAPIgDgCIgCAFIgDABIAFgHIgLgHIgJAUIgGACIAOgWIgMgGIgLAgIgHADIARgjQgGgDgGgCIgKAqIgIACIARgsIgNgEIgGAxIgIAEIANg1IgNgCIgBA3IgQAHIgBAAIgHADIAAAAIgIADIgLAFIgBABIgVAIIgBABIgIADIgogtIgJAJIAxAkIgHADIgqgnIgIALIAwAdIgIADIgogfIgHALIAsAVIgHADIgmgXIgFAMIAmAOIgHACIgfgPIgFANIAbAGIgGACIgVgIIgCANIAIACIgDABIgGgCIAAAFIgmAPQACg0AdgqgAgaAgIgjgxIgKAJIAtAogAgTAbIgfg1IgLAIIAqAtgAgMAWIgag3IgKAGIgCABIAmAwgAgGASIgUg5IgLAGIAfAzgAABAPIgNg7IgNAFIAaA2gAAJAMIgJg7IgLADIAUA4gAARALIgCg8IgOACIAQA6gAAiAKIAJg6IgOgBgAAPgxIAKA7IADg7gAhsgFQgFAGAHAGQADADAEgBQAEAAACgEQADgEgCgFIgFACQABABAAABQAAAAAAAAQAAAAAAABQAAABgBAAQgCAFgFgEQgDgCACgEQACgCADAAIAAgEQgGAAgCAEgAhYgdQgDACABAEQgBAEADADQADADAEAAQADAAAEgDQACgCAAgEQAAgEgCgDQgDgDgEAAQgEAAgDADgAhHgsIAQAMIADgCIgEgTIgEACIADANIgLgIgAgsg8IAIARIAEgCIgHgRgAgShGIgHACIAGASIAFgCQAKgCgDgJQgCgHgGAAIgDAAgAAxg5IAFACQAJACABgKQABgEgCgDQgBgDgDgBQgHgBgBAHQgBAGAFABQABAAABAAQAAAAABAAQAAAAABgBQAAAAABAAQgBADgFAAQAAAAAAAAQgBAAAAgBQAAAAAAAAQgBAAAAgBgAAhg6IAEABIABgTIgEAAQgBAFgEgBIAAAEIAAAAQABAAABAAQAAAAABAAQAAAAABgBQAAAAABgBgAAGhDIAAAEIAKgBIgBgEgAggAmg");
	this.shape_5.setTransform(-4.65,-9.4778);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgNAKIABgTIAFAAIAAAHIAUACIAAAEIgUgBIgBAHg");
	this.shape_6.setTransform(23.05,1.275);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgBANQgGgBgEgEQgDgFABgFQABgHAHgEIADAFQgFACgBAFQAAACACADQACADADABQADABADgCQADgDAAgDQABgFgFgDIAEgEQAHAGgCAHQAAAGgFADQgDADgEAAIgCgBg");
	this.shape_7.setTransform(22.8507,3.9611);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgOAFIAEgQIAFABIgDALIAFACIADgLIAFAAIgDAMIAFACIAEgMIAEABIgEARg");
	this.shape_8.setTransform(22.3,6.7);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgHADIgCAHIgFgCIAHgSIAFACIgDAHIAUAHIgCAFg");
	this.shape_9.setTransform(21.425,8.725);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgFANQgFgDgCgFQgCgGADgEQACgGAGgBQAEgCAFADQAFACACAGQACAFgDAEQgCAFgFADIgEAAQgDAAgDgBgAgCgIQgDABgCAEQgBADABADQABADADABQAHAFAEgIQAEgGgIgFIgEgBIgCAAg");
	this.shape_10.setTransform(20.5337,11.5);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgQAAIAGgJQAFgIAHAFQAFADgBAFIALACIgDADIgJgBIgEAFIAHAFIgCAFgAgHgGIgCAFIAIAEIABgEQADgEgDgDIgCgBQgBAAAAABQgBAAgBAAQAAABgBAAQAAABgBAAg");
	this.shape_11.setTransform(19.2,14.067);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgLgBIAGgJQAFgHAIAGQAIAGgHAHIgDAEIAGAFIgDAEgAgBgGIgDAEIAGAFIAEgDQACgEgDgDIgEgCQAAAAgBAAQAAABAAAAQAAAAAAABQgBAAAAABg");
	this.shape_12.setTransform(17.2759,16.1417);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgCADQgDgDADgCQACgDADADQADADgDACIgDABIgCgBg");
	this.shape_13.setTransform(16.2375,18.25);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgDgCIgGAEIgDgCIAOgOIADAEIgFAFIANAQIgDADg");
	this.shape_14.setTransform(14.2,19.1);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgQgEIAFgDIATAIIgJgPIADgCIAPAVIgEADIgUgIIAKAPIgEADg");
	this.shape_15.setTransform(12.325,21);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgNgHIAPgIIACAEIgKAGIACAFIALgFIACAEIgKAFIACAFIALgFIACAEIgPAIg");
	this.shape_16.setTransform(10.025,22.375);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgLgGIAFgBIANAPIAAgVIAEgCIABAcIgEADg");
	this.shape_17.setTransform(7.05,23.35);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgLgJIAQgGIACAGIgMACIACAHIALgDIACADIgMADIACAGIALgDIABAFIgQAFg");
	this.shape_18.setTransform(4.925,24.35);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgMgMIALgBQADgBADACQADACABAEQABAFgEADIAHAJIgGABIgGgIIgFABIACAIIgFABgAgBgJIgFABIABAIIAFAAQAFgBgBgEQgBgEgDAAIgBAAg");
	this.shape_19.setTransform(2.525,24.97);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgIAOIgCgaIAKgBQAKgBABAKQAAAKgKAAIgEAAIAAAIgAgEgIIAAAJIAEAAQAFAAAAgEQAAgFgFAAg");
	this.shape_20.setTransform(-0.075,25.1705);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AAAAEQgDAAAAgEQAAgEADABQAEAAAAADQgBAEgDAAIAAAAg");
	this.shape_21.setTransform(-2.525,25.5442);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AgKAMIAEgaIARADIgBAFIgMgCIAAAGIALACIAAAEIgMgCIgBAGIAMACIgBAFg");
	this.shape_22.setTransform(-4.925,24.9);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AADAOIgDgJIgEgBIgCAIIgFgBIAGgaIAJADQAKACgCAJQgBAEgGACIADALgAgDAAIAEAAQAFABABgDQABgFgFAAIgEgCg");
	this.shape_23.setTransform(-7.475,24.4);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AAHAOIAAgGIgJgDIgEADIgFgCIASgUIAEACIABAbgAAAAAIAHAEIAAgLg");
	this.shape_24.setTransform(-10.4,23.75);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AgNAMIALgYIAJAEQAJAFgEAIQgEAJgIgFIgFgCIgDAHgAgDADIAEACQAEACACgEQADgEgFgCIgFgCg");
	this.shape_25.setTransform(-12.049,22.4);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AgOAHIAOgXIAPAKIgDAFIgLgHIgCAFIAKAFIgCAFIgKgHIgEAGIAKAGIgCAFg");
	this.shape_26.setTransform(-14.1,21.55);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AgBAOIABgKIgEgDIgFAHIgFgEIAPgUIAJAGQAIAHgFAGQgEAEgFgBIgBALgAgCgCIAEACQADADADgDQADgDgEgDIgFgDg");
	this.shape_27.setTransform(-16.3288,20.175);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AgBAJIgEgDIgFAFIgEgDIARgTIAIAHQAHAFgGAIQgDADgEAAQgEAAgCgDgAgCACIADAEQADADAEgDQADgEgEgDIgEgEg");
	this.shape_28.setTransform(-18.2991,18.05);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AgJALQgFgFAAgGQgBgFAEgFQAEgFAHAAQAFAAAFAEQAFAEAAAGQABAFgEAGIgCACIgQgNQgBADADAEQAEACACgBIADAIIgEABQgFAAgFgFgAgBgGIAIAHQACgDgEgDQAAgBgBAAQgBAAAAgBQgBAAAAAAQgBAAAAAAIgCABg");
	this.shape_29.setTransform(13.775,-18.5278);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFFFFF").s().p("AgHARQgJgGAGgJIAGgIIgEgDIAEgHIAEADIADgFIAKABIgGAJIAGAEIgFAGIgGgDIgEAHQAAABAAABQgBAAAAABQAAAAABABQAAAAAAABIACAAIAAAIIAAAAQgDAAgEgCg");
	this.shape_30.setTransform(11.8509,-20.5208);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFFFFF").s().p("AgCAFQgEgDACgDQADgGADADQAGADgDADQgCAEgDAAIgCgBg");
	this.shape_31.setTransform(10.7333,-23.45);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFFFF").s().p("AgKALIANgZIAIAEIgMAZg");
	this.shape_32.setTransform(9.65,-21.475);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("AAAAVIAGgPQADgFgFgBQgEgBgBAEIgGAPIgJgEIAQgmIAIADIgGAPQADgCAFACQAKAEgEAKIgHASg");
	this.shape_33.setTransform(7.2343,-23.2);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FFFFFF").s().p("AAAAXIgCgaIgMAWIgJgCIgCgpIAJADIABAZIAMgXIAHACIADAZIALgVIAJACIgTAkg");
	this.shape_34.setTransform(3.7,-24.6);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FFFFFF").s().p("AgQASQgEgEAAgEQAAgGAIgFQgEgEAAgEQAAgFADgDQADgDAFAAQAKAAAAAKQAAAFgFAFIADADIAGgGIALAAIgLAMIAMALIgNAAIgEgFQgFAGgGAAQgGAAgDgDgAgKAJQAAABAAAAQAAABABAAQAAABABAAQAAAAABAAQADAAADgCIgGgGQgDADAAACgAgIgKQABADACACQADgCAAgDQAAAAAAgBQgBAAAAgBQAAAAgBAAQAAAAgBAAQAAAAgBAAQgBAAAAAAQAAABgBAAQAAABAAAAg");
	this.shape_35.setTransform(-2.075,-25.075);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#FFFFFF").s().p("AgEALIgCgKIgGABIgBgHIAEgBIgBgHIAIgGIACALIAGgCIACAIIgHACIACAIQAAABABABQAAAAAAABQABAAAAAAQABABAAAAIACgCIAGAGQgEAEgDAAIgDAAQgGAAgCgJg");
	this.shape_36.setTransform(-6.6,-24.7034);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#FFFFFF").s().p("AgEALIgDgKIgFABIgCgGIAFgCIgCgGIAHgHIADAKIAGgCIACAIIgGACIADAJQAAABAAAAQAAABABAAQAAABABAAQABAAAAgBQABAAAAAAQAAAAAAAAQABAAAAAAQAAgBAAAAIAGAFQgCAEgFABIgDABQgGAAgDgJg");
	this.shape_37.setTransform(-9.025,-24.094);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#FFFFFF").s().p("AgFAPQgGgDgCgGQgDgGACgFQACgGAHgCQAFgDAGACQAGADACAFQADAGgCAFQgCAGgHADIgGACIgFgBgAgCgFQgFADACAFQADAGAFgDQAGgCgDgGQgCgEgDAAIgDABg");
	this.shape_38.setTransform(-11.775,-22.475);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#FFFFFF").s().p("AgDAPQgGgCgDgFQgEgFACgGQABgGAFgDQAIgGAJAGIgGAIQgDgDgDACQgCABgBADQAAACABACQAEAGAEgEQAEgCgBgDIAJgCQABAKgIAFQgEADgEAAIgDgBg");
	this.shape_39.setTransform(-14.5422,-20.9965);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#FFFFFF").s().p("AgEAVIACgLQAFADAFgFQAEgDgDgDQgCgCgHAEQgKAGgGgHQgDgDABgFQAAgGAFgEQAHgGAJABIgCAKQgEgCgFAEQgEADADACQACACAHgDQAKgHAGAIQAEADgBAGQgBAFgFAEQgGAGgHAAIgEAAg");
	this.shape_40.setTransform(-17.683,-19.3111);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#FFFFFF").s().p("AgNAAIAFgHIAEADQgDgFAEgFIADgDIAFAIIgDADQgDAFAEADIALAJIgGAHg");
	this.shape_41.setTransform(-20.625,-16.025);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FFFFFF").s().p("AgHAOQgGgEgBgGQgCgFAEgHQADgFAHgCQAFgBAFAEQAGADABAHQABAFgDAFQgEAGgGACIgDAAQgDAAgEgCgAgFgCQgDAEAFAEQAFAEADgHQAEgEgGgEIgDgBQgCAAgDAEg");
	this.shape_42.setTransform(-22.0864,-13.45);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#FFFFFF").s().p("AgUgFIAEgIIAlATIgEAIg");
	this.shape_43.setTransform(-23.9,-11.55);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#FFFFFF").s().p("AAJAQQABAAAAgBQABAAAAAAQAAgBABAAQAAgBAAAAQABgDgDgDIgBgBIgdAAIADgIIARAAIgMgLIADgJIAYAWQAIAHgDAJQgCAFgEADg");
	this.shape_44.setTransform(-24.0609,-8.75);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#FFFFFF").s().p("AACAQQgIgDACgNIACgGQgEgBgBAFQgBAEACACIgFAHQgGgHACgHQADgOAMADIAQAEIgBAJIgEgBQADADgBAHQgBAIgHAAIgDAAgAACAAQgBAFADABQAAAAABAAQAAgBABAAQAAAAAAgBQABAAAAgBQABgFgEgCIgBAAg");
	this.shape_45.setTransform(-25.1267,-5.7029);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#FFFFFF").s().p("AgTANIABgPQABgOALABQAGABABADQACgEAGAAQAMACgBAOIgBAQgAAEAAIAAAGIAHABIABgHQABgFgFAAIAAAAQgDAAgBAFgAgKgBIgBAGIAIAAIAAgGQAAgFgDAAQgEAAAAAFg");
	this.shape_46.setTransform(-26.2712,-2.3032);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#FFFFFF").s().p("AgEgCIACgBQAEgEACAGQADADgFADIgCABg");
	this.shape_47.setTransform(6.2313,14.4319);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#FFFFFF").s().p("AAAACQgBAAAAgBQgBAAAAAAQAAgBABAAQAAAAAAAAQAAgBABAAQAAAAAAAAQAAAAAAAAQABAAABAAQAAAAAAABQABAAAAAAQAAAAAAAAQgBABAAAAIgCABIAAAAg");
	this.shape_48.setTransform(11.3256,9.2533);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#FFFFFF").s().p("AgEAAQAAgEAEAAQAFAAAAAEQAAAAAAABQAAAAAAABQAAAAAAABQgBAAAAABQAAAAgBAAQAAABgBAAQAAAAgBAAQAAAAgBAAQgDAAgBgFg");
	this.shape_49.setTransform(-1.0937,16.375);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#FFFFFF").s().p("AgCADQgEgDADgDQAEgDADAEQADACgDAEQgBAAAAAAQgBABAAAAQAAAAgBAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQAAAAgBgBQAAAAAAgBg");
	this.shape_50.setTransform(-12.8567,-11.8317);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#FFFFFF").s().p("AgDgDIACgBQAEgBABAFQABAEgEABIgBAAg");
	this.shape_51.setTransform(-6.2659,-15.6173);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#FFFFFF").s().p("AgBAAQAAAAAAAAQAAgBAAAAQABAAAAAAQAAgBAAAAQABABAAAAQABAAAAAAQAAABAAAAQAAAAAAAAQAAABAAAAQAAABAAAAQgBAAAAAAQgBABAAAAQAAgBAAAAQgBAAAAgBQAAAAAAgBQAAAAAAAAg");
	this.shape_52.setTransform(1.1208,-16.3);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#FFFFFF").s().p("AhvCkQhlgdg/hVIAEgBQA+BTBkAcQBlAeBfgoQBggoAzhcQAyhagPhnIAEgBQANBaglBTQglBShLAxQgbARgWAJQg4AXg5AAQgqAAgsgNg");
	this.shape_53.setTransform(1.4707,13.7011);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#FFFFFF").s().p("AjugTQAzheBjgpQA4gYA8ABQA9AAA5AZQBPAhA0BHIgEABQgxhEhPgiQg5gYg8AAQg7gBg4AXQgZALgXAPQhLAwgkBSQgkBTANBZIgDACQgRhqAzhcg");
	this.shape_54.setTransform(-4.8282,-13.5005);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#FFFFFF").s().p("AiSAXQAOgjAagaQAbgbAjgPQAjgOAkAAQAmAAAjAPQAjAPAaAbIgEABQgagZgggOQgigPgmAAQgjAAgjAOQgQAIgNAHQgxAggWA2QgNAhAAAjIgEACQAAglAOgjg");
	this.shape_55.setTransform(-4.65,-9.85);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#FFFFFF").s().p("AhlBOQghgOgZgZIAEgBQAZAXAfANQAiAPAlAAQAkAAAigOQAjgOAagaQAZgaAOgiQANggABgiIAEgBQgBAkgNAgQgWA3gyAgQgLAIgTAIQgjAOglAAQglAAgkgPg");
	this.shape_56.setTransform(1.325,10.075);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#FFFFFF").s().p("AkDgVQA3hoBrgsQBrgtBwAjQBvAiBDBfIgPAGQhBhZhogfQhqgghkAqQgdAMgVAOQhOAzgmBWQglBWAPBeIgQAGQgThyA2hmg");
	this.shape_57.setTransform(-4.9087,-14.2283);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#FFFFFF").s().p("AhmDLQhmgYhGhOIgCgDIhxAMIBsgsIAAAAIAHAIIABACQBBBSBlAbQBmAcBhgoQBigpA1hdQA0hbgNhqIgCgJIBvgtIhbBJIAAADQAEBagnBOQgoBRhKAwQgbARgaAKQg8AZg9AAQgnAAgogKg");
	this.shape_58.setTransform(1.4,12.4676);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#FFFFFF").s().p("AADAaIAAAAIgnhfIBKgfIgjBZIBYAlIi1BLg");
	this.shape_59.setTransform(41.125,-11.825);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#FFFFFF").s().p("AgdgJIhXgmIBLgfIAoBdIAAACIB2gOIi1BMg");
	this.shape_60.setTransform(-38.425,22.25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.safeCare_logo, new cjs.Rectangle(-50.1,-33.7,100.30000000000001,67.5), null);


(lib.CC_Logo = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("An3GrQhvgzg5hvQA9gOAmg1QAyhHAAiDQAAiBgwhHQglg1g8gQQA6hqBtgwQBHgfBCAAQBDAAAmAHIAADFQgbgFgkAAQg8AAgtA3Qg5BGAACGQAACGA5BHQAtA3A8AAQAiAAAhgFIAADFQgqAHhDAAQhDAAhJgggAxvHIIgdgEIAAjFQAhAFAhAAQA9AAAsg3QA5hHAAiGQAAiGg5hGQgsg3g9AAQgjAAgcAFIAAjFIAcgEQAkgDApAAQBCAABHAfQBsAwA7BpQg9APgmA1QgxBHAACDQAACFAzBHQAnA0A+AOQg5BuhvAzQhIAghEAAQgpAAgmgDgAEQGEQgUgRAAgdQAAggAXgTQAVgRAgAAQAMAAAaAGIADAfIgHACQgHgfgeAAQgUAAgNAPQgOAQAAAaQAAAYAMAQQAOAUAXAAQAJAAAEgDQAFgCAAgJIAAgSQAAgLgDgCQgDgDgPgBIAAgGIA3AAIAAAGQgIABgBADQgCACAAAJIAAAQQAAANABAFQghAHgLAAQghAAgUgSgAB0GEQgTgTAAgcQAAgbASgTQATgUAfAAQAaAAASASQATASAAAcQAAAegTATQgTASgcAAQgcAAgSgSgACHEpQgLAPAAAZQAAAaALARQAMASATAAQAQAAAKgNQAKgPAAgaQAAgdgMgRQgLgQgSAAQgQAAgKAPgAH7GVQgPgBgIgEQgIgEgGgKIgRgdQgFgIgKAAIgEAAIAAAdQAAAMADADQACADAMABIAAAGIg4AAIAAgGQALgBADgDQADgDAAgMIAAhMQAAgMgDgDQgCgDgLgBIAAgGIA0AAQAWAAALAHQANAIAAASQAAAWgYAKQAHAOAJAOQAKAQAFAFQAGAGAHACIgBAGgAG0EeQgCACAAAGIAAAwIAGAAQAOAAAGgGQAKgHAAgQQAAgPgIgHQgHgHgKAAQgHAAgCACgABRGVQgPgBgIgEQgHgEgHgKIgRgdQgEgIgKAAIgEAAIAAAdQAAAMACADQADADALABIAAAGIg2AAIAAgGQALgBACgDQADgDAAgMIAAhMQAAgMgCgDQgDgDgLgBIAAgGIAzAAQAXAAALAHQANAJAAARQAAAWgZAKQAHAOAKAOQAIANAHAIQAFAGAHACIgBAGgAAKEeQgBACAAAGIAAAwIAGAAQAOAAAGgGQAKgIAAgPQAAgOgIgIQgHgHgKAAQgHAAgDACgAMCGTIAAgGQALgBACgDQADgDgBgPIAAhMIgBAAIgsBnIgFAAIgphlIgBAAIgCA1QgCAVABAKQABAHADACQAEACAKABIAAAGIguAAIAAgGQAOgCACgJQACgJACgcIADgnQABgRgDgEQgCgEgNgCIAAgGIAlAAIAoBZIAphZIAkAAIAAAGQgMACgCADQgCADAAANIACBHQAAAPADADQACADAMABIAAAGgAJWGTIAAgGQAJgBABgCQACgDgCgGIgJgZIgnAAIgHAXQgDAIACACQACADALABIAAAGIgrAAIAAgGQAJgBAEgDQAEgEAFgMIAohkIAIgDIAlBmQAFANAEAEQADADAJABIAAAGgAI0FfIAgAAIgQgtgAiSGTIAAgGQALgBADgDQADgDAAgMIAAhMQAAgMgDgDQgCgDgLgBIAAgGIA0AAQAXAAAKAIQAOAKAAASQAAASgMALQgLAJgQACIgIAAIgOgDIAAAcQAAANADACQADADANABIAAAGgAhpEeQgCADAAAFIAAAxQAEACAIAAQAJAAAGgGQAJgIAAgRQAAgPgIgIQgHgHgLAAQgFAAgDACgACNDAQgRgSAAgaQAAgeAVgTQAVgTAiAAQAHAAAcAGIAEAfIgHABQgHgegdAAQgWAAgMARQgMAQAAAXQAAAbANARQAOAQAUAAQAYAAAPgeIAGADQgGAVgFAJQgZAFgKAAQgjAAgUgUgAAFDAQgQgSAAgaQAAgeAUgTQAVgTAiAAQAHAAAcAGIAEAfIgGABQgIgegdAAQgVAAgNARQgMAQAAAXQAAAbANARQAOAQAUAAQAYAAAPgeIAGADQgFATgFALQgcAFgIAAQgjAAgUgUgAFxDTQgPAAgIgFQgIgDgGgKIgRgeQgEgIgLAAIgEAAIAAAdQAAAMADADQACADAMABIAAAGIg4AAIAAgGQALgBADgDQADgDAAgMIAAhMQAAgLgDgDQgCgDgLgBIAAgHIA0AAQAXAAAKAHQANAKAAAQQAAAWgYAKQAGANAKAPQAIAMAHAJQAHAHAGABIgBAGgAEqBdQgCABAAAGIAAAwIAHAAQANAAAGgFQAKgJAAgPQAAgOgIgIQgGgGgLAAQgHAAgCACgAPEDRIAAgGQAMAAADgDQADgDAAgNIAAhLQAAgNgCgDQgDgCgLgBIAAgHIA5AAQAmAAASARQARAQAAAZQAAAhgZATQgVAQglAAgAPvBdQgCACAAAJIAABPQAAALAEAEQAEAEAKAAQAWAAAMgQQANgQAAgZQAAgegSgOQgMgKgUAAQgLAAgCACgANQDRIAAgGQANgBADgDQADgDAAgMIAAhLQAAgNgDgDQgDgCgLgBIAAgHIBaAAIACAdIgHABQgCgKgFgHQgEgFgQAAIgMAAQgFAAgBABQgBABAAAFIAAAqIAPAAQANAAADgCQAEgCACgLIAGAAIAAAnIgGAAQgCgKgEgDQgDgCgNAAIgPAAIAAAjQAAANAFADQADACAPAAQARAAAGgHQAEgEAGgOIAHABQgDASgEANgALsDRIAAgGQANgBADgDQADgDAAgMIAAhdIgJAAQgSAAgEAGQgEAEgEAPIgGAAIACglIAFAAQABADADABIAGAAIBOAAQAGAAAFgEIAEAAIACAkIgGAAQgEgOgEgFQgFgFgPAAIgLAAIAABdQAAAMADADQADADAOABIAAAGgAKJDRIAAgGQAMgBACgDQADgDAAgMIAAhLQAAgNgDgDQgCgCgMgBIAAgHIA4AAIAAAHQgMABgCACQgDADAAANIAABLQAAAMADADQACADAMABIAAAGgAH1DRIAAgGQAMAAADgDQACgDAAgNIAAhLQAAgNgCgDQgDgCgLgBIAAgHIA5AAQAnAAARARQARAQAAAZQAAAigYASQgVAQgmAAgAIfBdQgCACAAAJIAABPQAAALAEAEQAEAEAKAAQAWAAANgQQAMgQAAgZQAAgegRgOQgNgKgTAAQgLAAgDACgAGADRIAAgGQANgBADgDQADgCAAgNIAAhLQAAgNgDgDQgCgCgLgBIAAgHIBZAAIACAdIgGABQgDgMgEgFQgFgFgQAAIgLAAQgFAAgCABQgBABAAAFIAAAqIAPAAQANAAADgCQAEgCACgLIAGAAIAAAnIgGAAQgCgKgEgDQgDgCgNAAIgPAAIAAAjQAAANAFADQAEACAPAAQAQAAAGgHQAFgFAGgNIAGABQgCAOgFARgAhJDRIAAgGQAIgBACgCQACgDgCgGIgJgZIgnAAIgHAXQgDAIACACQACADAKABIAAAGIgqAAIAAgGQAJgBAEgDQADgDAFgNIAohkIAJgDIAlBnQAFAMADAEQAEADAJABIAAAGgAhsCdIAhAAIgQgtIAAAAgArmBqQgMglAAhJQAAhKAMglQALghAUAAQATAAALAhQANAlAABKQAABJgNAlQgLAhgTAAQgUAAgLghgADjgSQgTgKgLgUQgLgTAAgZQAAgpAZgaQAagbAlAAQANAAATAFQAKACAGAAQAHAAACgFIAEAAIAAAzIgFAAQgGgYgNgLQgOgLgWAAQgdAAgRAVQgRAUAAAjQAAAnASAXQASAXAdAAQApAAASglIAFAEQgIAUgUAMQgUAMgXAAQgYAAgTgLgALjgXQgQgQAAgYQAAgXAPgRQAQgQAVAAQATAAANAMQAOAMAAARIAAADIhNAAIAAABQAAASAFAMQAFAMAKAIQALAIAKAAQALAAAHgFQAJgFALgMIAAAHQgKANgKAFQgJAFgPAAQgYAAgQgPgALwhoQgIAJAAAPIA5AAIAAgCQAAgPgIgIQgIgIgMAAQgOAAgHAJgAJugXQgPgPAAgXQAAgYAQgRQAQgRAXAAQAJAAANAEIAHACQAFAAADgGIAFAAIAAAlIgFAAQgEgPgJgIQgKgIgNAAQgPAAgKAMQgKAMAAATQAAAVALAQQAMAQAQAAQALAAAKgGQAKgFAJgLIAAAIQgRAXgeAAQgYAAgOgPgAGkgXQgHAIgHAEQgGADgIAAQgNAAgJgIQgJgIAAgMQAAgKAIgIQAIgIAXgGIAUgHIAAgIQAAgLgHgHQgGgHgLAAQgJAAgIAGQgHAGgDAKIgGgBQADgPALgIQALgJAOAAQAQAAALAKQALAKAAASIAAAtQAAAKABADQACAEADAAQAAAAABAAQAAAAABgBQAAAAABAAQAAgBABAAIADgJIAFAAQgBAKgFAGQgGAGgIAAQgNAAgFgPgAGXhAQgRAHgDAEQgFAGAAAIQAAAJAFAFQAEAGAHAAQAGAAAHgEQAGgEADgGIAAgjgAiLgYQgRgPAAgZQAAgXARgQQARgQAYAAQAZAAAQAQQARAQAAAXQAAAZgRAPQgQAQgZAAQgZAAgQgQgAh8hkQgKANAAAYQAAAXAKANQAKANAQAAQARAAAJgNQAKgPAAgVQAAgWgKgPQgJgNgRAAQgQAAgKANgANDgLIAAgFQALAAADgEQAEgDAAgOIAAg5QAAgLgEgDQgEgDgOAAIAAgFIAlgDIAFAAIAAAWIAXgRQAHgFAGAAQAJAAAKAIIgIATQgRgKgIAAQgJAAgNANIAAA6QAAAJAEADQAEADAKAAIAAAFgAIegLIAAgFQALAAADgDQAEgDAAgHIAAg3QAAgKgGgIQgHgGgKAAQgPAAgPAUIAAAzQAAAOADADQAEAEAKAAIAAAFIg3AAIAAgFQAMAAADgEQACgDAAgOIAAg7QAAgJgDgDQgDgDgLAAIAAgFIAhgDIAFAAIAAAVQATgVATAAQAPAAAKAKQAKAKAAARIAAAwQAAAKAEAEQAEAEAKAAIAAAFgAAqgLIAAgFQALAAADgDQAEgCAAgIIAAg3QAAgLgGgHQgHgGgKAAQgPAAgPAUIAAAzQAAAOADADQAFAEAJAAIAAAFIg2AAIAAgFQAMAAADgEQADgEAAgNIAAg7QAAgJgEgDQgDgDgLAAIAAgFIAggDIAFAAIAAAVQATgVATAAQAQAAAJAKQALALAAAQIAAAwQAAALADADQAFAEAJAAIAAAFgAPKhiQgKgFgGgKQgFgKAAgLQAAgMAFgJQAHgLAJgFQAJgFAMAAQAMAAAJAFQAJAFAGALQAGAKAAALQAAALgGAKQgGAKgJAFQgKAGgLAAQgLAAgKgGgAPDiiQgLAMAAAQQAAAPALAMQALALARAAQAQAAALgLQAMgMAAgPQAAgQgMgMQgLgLgQAAQgQAAgMALgAPrhtIgRgYIgDgBIgCABIAAANQAAAGACABQABACAFAAIAAACIgWAAIAAgCQAFAAABgCIABgHIAAgfIgBgGQgBgCgEAAIgBAAIAAgCIAUAAQAJAAAFAEQAEAEAAAFQAAAGgDADQgEAEgGAAIALAQIAGAGIAGACIAAACgAPVidIAAAVIADAAQAHAAADgDQAEgDAAgGQAAgFgDgDQgEgCgFAAgAhrjsQgUgKgKgUQgLgSAAgZQAAgpAZgbQAZgaAmAAQANAAATAEIAQADQAHAAACgGIADAAIAAAzIgEAAQgGgYgNgLQgNgLgXAAQgcAAgSAVQgRAVAAAjQAAAmASAXQASAYAdAAQApAAARgmIAFAEQgIAVgTALQgSAMgZAAQgYAAgTgLgAOfjxQgRgRAAgXQAAgYARgQQAQgQAZAAQAZAAAQAQQARAQAAAYQAAAXgRARQgQAPgZAAQgZAAgQgPgAOuk+QgKANAAAYQAAAXAKANQAKAOAQAAQARAAAJgOQAKgOAAgWQAAgWgKgOQgKgOgQAAQgQAAgKANgAMIjnQgFgCgDAAQgBAAgBAAQAAAAgBAAQAAAAgBABQAAAAgBABQgBABgBAEIgFAAIAAgkIAFAAQADAOAJAIQAKAJAMAAQAHAAAGgGQAFgFAAgHQAAgIgFgFQgEgGgRgHQgSgIgGgHQgGgGAAgLQAAgMAKgJQAKgJAMAAQAGAAAIADIAIACQAEAAACgFIAFAAIAAAhIgGAAQgBgNgIgHQgGgHgLAAQgHAAgGAEQgEAEAAAGQAAAGAEAGQAFAFAOAGQASAIAHAJQAHAIAAALQAAANgKAKQgKAJgOAAQgHAAgLgFgAKqjnQgFgCgDAAQgDAAgCACIgCAFIgFAAIAAgkIAFAAQADAOAKAIQAJAJAMAAQAIAAAFgGQAGgFAAgHQAAgIgFgFQgGgGgPgHQgTgIgFgHQgGgGAAgLQAAgMAJgJQAKgJANAAQAGAAAHADIAIACQAEAAADgFIAFAAIAAAhIgGAAQgCgNgHgHQgHgHgLAAQgHAAgFAEQgFAEAAAGQAAAHAEAFQAFAFAPAGQASAIAHAJQAGAIAAALQAAANgKAKQgJAJgOAAQgHAAgMgFgAAtjxQgRgRAAgXQAAgYAQgQQAQgQAaAAQAZAAAQAQQAQAQAAAYQAAAXgQARQgQAPgZAAQgZAAgQgPgAA8k+QgKAOAAAXQAAAWAJAOQAKAOARAAQARAAAJgOQAJgNAAgXQAAgXgJgNQgKgOgQAAQgRAAgJANgARVjlIAAgFQALAAADgDQAEgCAAgIIAAg3QAAgLgGgGQgHgHgKAAQgPAAgPAVIAAAzQAAANADADQADAEALAAIAAAFIg3AAIAAgFQAMAAADgEQADgDAAgNIAAg7QAAgKgEgDQgDgDgLAAIAAgFIAhgDIAFAAIAAAVQATgVATAAQAQAAAJALQALAKAAARIAAAvQAAALADAEQAFADAJAAIAAAFgANJjlIAAgFQANAAADgDQAEgDAAgIIAAhBQAAgJgDgEQgDgDgOAAIAAgFIAjgDIAFAAIAABZQAAAIAEADQAEADAKAAIAAAFgAJLjlIAAgFQANAAADgDQAEgDAAgIIAAhBQAAgKgDgDQgEgDgNAAIAAgFIAjgDIAFAAIAABZQAAAIAEADQAEADAKAAIAAAFgAIFjlIAAgFQALAAAEgEQADgDAAgNIAAgyQAAgKgGgGQgGgGgLAAQgQAAgOAVIAAA4QAAAIAEAEQAEADAKAAIAAAFIg4AAIAAgFQAMAAADgEQADgEAAgMIAAgxQAAgKgGgGQgGgHgKAAQgJAAgIAGQgIAGgGAJIAAA5QAAAIAEADQAGADAIAAIAAAFIg4AAIAAgFQAMAAADgEQADgDAAgKIAAg+QAAgJgDgDQgEgEgHAAIgHAAIAAgFIAkgDIAFAAIAAAWIABAAQAGgJALgHQAKgGAKAAQAMAAAJAHQAJAGADALQASgYAVAAQAQAAAKAKQAKAIAAASIAAA0QAAAJAEADQAEADAKAAIAAAFgAEtjlIAAgFQALAAADgEQAEgEAAgMIAAgyQAAgKgHgGQgGgGgKAAQgRAAgNAVIAAA4QAAAIAEAEQAEADAKAAIAAAFIg4AAIAAgFQAMAAADgEQADgEAAgMIAAgxQAAgKgGgGQgHgHgKAAQgIAAgIAGQgJAGgFAJIAAA5QAAAIAEADQAFADAJAAIAAAFIg4AAIAAgFQALAAAEgEQADgDAAgKIAAg+QAAgIgDgEQgFgEgHAAIgGAAIAAgFIAkgDIAFAAIAAAWIABAAQAGgKALgGQAKgGAKAAQAMAAAJAHQAJAGADALQARgYAWAAQAQAAAKAKQAKAJAAARIAAA0QAAAJAEADQAEADAJAAIAAAFgANelxQgEgEAAgFQAAgFAEgEQAEgEAGAAQAFAAAEAEQADADAAAGQAAAFgDAEQgEAEgFAAQgFAAgFgEgAJglxQgEgEAAgFQAAgFAEgEQAEgEAGAAQAFAAAEAEQADADAAAGQAAAFgDAEQgEAEgFAAQgGAAgEgEg");
	this.shape.setTransform(0.025,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.CC_Logo, new cjs.Rectangle(-116.5,-45.9,233.1,91.9), null);


(lib.BSWH_Icon = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// blue_bottom
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#1B449D").s().p("AgFAQIAAgUIALgLIAAAfg");
	this.shape.setTransform(-0.625,1.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#1B449D").s().p("AgWBBIAAhUIAtgtIAACBg");
	this.shape_1.setTransform(-2.525,6.825);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#1B449D").s().p("AgkBsIAAiMIBJhLIAADXg");
	this.shape_2.setTransform(-4.175,11.275);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#1B449D").s().p("AgxCQIAAi8IBihjIAAEfg");
	this.shape_3.setTransform(-5.55,15.075);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#1B449D").s().p("Ag7CtIAAjiIB3h3IAAFZg");
	this.shape_4.setTransform(-6.675,18.15);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#1B449D").s().p("AhDDEIAAkAICHiHIAAGHg");
	this.shape_5.setTransform(-7.575,20.525);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#1B449D").s().p("AhIDUIAAkVICRiTIAAGog");
	this.shape_6.setTransform(-8.225,22.25);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#1B449D").s().p("AhMDeIAAkiICYiZIAAG7g");
	this.shape_7.setTransform(-8.6,23.3);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#1B449D").s().p("AhNDiIAAknICbicIAAHDg");
	this.shape_8.setTransform(-8.725,23.625);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},5).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_8}]},6).to({state:[]},1).wait(352));

	// blue_Rt
	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#1B449D").s().p("AgEAFIgLgKIAfAAIAAAKg");
	this.shape_9.setTransform(1.7,0.65);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#1B449D").s().p("AgTAWIgtgsICBAAIAAAsg");
	this.shape_10.setTransform(6.825,2.55);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#1B449D").s().p("AggAlIhLhJIDXAAIAABJg");
	this.shape_11.setTransform(11.275,4.225);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#1B449D").s().p("AgsAyIhjhiIEfAAIAABig");
	this.shape_12.setTransform(15.075,5.65);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#1B449D").s().p("Ag1A8Ih3h3IFZAAIAAB3g");
	this.shape_13.setTransform(18.15,6.775);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#1B449D").s().p("Ag8BEIiHiHIGHAAIAACHg");
	this.shape_14.setTransform(20.525,7.675);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#1B449D").s().p("AhBBJIiTiRIGoAAIAACRg");
	this.shape_15.setTransform(22.25,8.325);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#1B449D").s().p("AhEBNIiZiYIG7AAIAACYg");
	this.shape_16.setTransform(23.3,8.7);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#1B449D").s().p("AhFBOIicibIHDAAIAACbg");
	this.shape_17.setTransform(23.625,8.825);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_9}]},9).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_17}]},2).to({state:[]},1).wait(352));

	// lt_blue_lt
	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#1690BF").s().p("AgKAFIAAgKIAVAAIgLAKg");
	this.shape_18.setTransform(-1.15,0.65);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#1690BF").s().p("AgsAWIAAgsIBZAAIgtAsg");
	this.shape_19.setTransform(-4.725,2.55);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#1690BF").s().p("AhJAlIAAhJICTAAIhKBJg");
	this.shape_20.setTransform(-7.825,4.225);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#1690BF").s().p("AhhAyIAAhiIDDAAIhiBig");
	this.shape_21.setTransform(-10.425,5.65);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#1690BF").s().p("Ah1A8IAAh3IDrAAIh2B3g");
	this.shape_22.setTransform(-12.55,6.775);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#1690BF").s().p("AiFBEIAAiHIELAAIiHCHg");
	this.shape_23.setTransform(-14.225,7.675);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#1690BF").s().p("AiQBJIAAiRIEhAAIiSCRg");
	this.shape_24.setTransform(-15.425,8.325);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#1690BF").s().p("AiXBNIAAiYIEvAAIiYCYg");
	this.shape_25.setTransform(-16.15,8.7);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#1690BF").s().p("AiZBOIAAibIEzAAIibCbg");
	this.shape_26.setTransform(-16.375,8.825);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_18}]}).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_26}]},11).to({state:[]},1).wait(352));

	// blue_lt
	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#1B449D").s().p("AgPAGIAAgLIAUAAIALALg");
	this.shape_27.setTransform(-1.675,-0.625);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#1B449D").s().p("AhAAXIAAgtIBUAAIAtAtg");
	this.shape_28.setTransform(-6.8,-2.525);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#1B449D").s().p("AhrAlIAAhJICMAAIBLBJg");
	this.shape_29.setTransform(-11.25,-4.175);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#1B449D").s().p("AiPAyIAAhiIC8AAIBjBig");
	this.shape_30.setTransform(-15,-5.6);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#1B449D").s().p("AitA8IAAh3IDjAAIB4B3g");
	this.shape_31.setTransform(-18.075,-6.725);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#1B449D").s().p("AjEBEIAAiHIEAAAICICHg");
	this.shape_32.setTransform(-20.45,-7.625);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#1B449D").s().p("AjUBJIAAiRIEWAAICTCRg");
	this.shape_33.setTransform(-22.175,-8.275);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#1B449D").s().p("AjeBNIAAiYIEjAAICaCYg");
	this.shape_34.setTransform(-23.225,-8.65);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#1B449D").s().p("AjhBOIAAibIEnAAICcCbg");
	this.shape_35.setTransform(-23.55,-8.775);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_27}]},7).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_35}]},4).to({state:[]},1).wait(352));

	// yellow_top
	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#FDB61B").s().p("AgFAAIAAgKIALAAIAAAVg");
	this.shape_36.setTransform(-0.625,-1.15);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#FDB61B").s().p("AgWAAIAAgsIAtAAIAABZg");
	this.shape_37.setTransform(-2.525,-4.725);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#FDB61B").s().p("AgkAAIAAhJIBJAAIAACTg");
	this.shape_38.setTransform(-4.175,-7.825);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#FDB61B").s().p("AgxAAIAAhhIBiAAIAADDg");
	this.shape_39.setTransform(-5.55,-10.45);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#FDB61B").s().p("Ag7AAIAAh1IB3AAIAADrg");
	this.shape_40.setTransform(-6.675,-12.575);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#FDB61B").s().p("AhDgBIAAiEICHAAIAAELg");
	this.shape_41.setTransform(-7.575,-14.25);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FDB61B").s().p("AhIAAIAAiQICRAAIAAEhg");
	this.shape_42.setTransform(-8.225,-15.45);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#FDB61B").s().p("AhMAAIAAiXICYAAIAAEvg");
	this.shape_43.setTransform(-8.6,-16.175);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#FDB61B").s().p("AhNgBIAAiYICbAAIAAEzg");
	this.shape_44.setTransform(-8.725,-16.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_36}]}).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_44}]},11).to({state:[]},1).wait(352));

	// blue_top
	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#1B449D").s().p("AgFgPIAKAAIAAAUIgKALg");
	this.shape_45.setTransform(0.65,-1.675);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#1B449D").s().p("AgWhAIAsAAIAABUIgsAtg");
	this.shape_46.setTransform(2.55,-6.8);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#1B449D").s().p("AgkhrIBJAAIAACMIhJBLg");
	this.shape_47.setTransform(4.225,-11.25);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#1B449D").s().p("AgwiPIBiAAIAAC8IhiBjg");
	this.shape_48.setTransform(5.65,-15.025);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#1B449D").s().p("Ag7itIB3AAIAADjIh3B4g");
	this.shape_49.setTransform(6.775,-18.1);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#1B449D").s().p("AhDjDICHAAIAAEAIiHCHg");
	this.shape_50.setTransform(7.675,-20.475);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#1B449D").s().p("AhIjUICRAAIAAEWIiRCSg");
	this.shape_51.setTransform(8.325,-22.2);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#1B449D").s().p("AhLjeICYAAIAAEkIiYCZg");
	this.shape_52.setTransform(8.7,-23.25);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#1B449D").s().p("AhNjhICbAAIAAEnIibCcg");
	this.shape_53.setTransform(8.825,-23.575);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_45}]},5).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_52}]},1).to({state:[{t:this.shape_53}]},1).to({state:[{t:this.shape_53}]},6).to({state:[]},1).wait(352));

	// lt_blue_rt
	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#1690BF").s().p("AgKAGIAKgLIALAAIAAALg");
	this.shape_54.setTransform(1.2,-0.625);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#1690BF").s().p("AgsAXIAsgtIAtAAIAAAtg");
	this.shape_55.setTransform(4.775,-2.525);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#1690BF").s().p("AhJAlIBKhJIBJAAIAABJg");
	this.shape_56.setTransform(7.875,-4.175);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#1690BF").s().p("AhhAyIBihiIBhAAIAABig");
	this.shape_57.setTransform(10.525,-5.6);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#1690BF").s().p("Ah1A8IB2h3IB1AAIAAB3g");
	this.shape_58.setTransform(12.65,-6.725);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#1690BF").s().p("AiFBEICGiHICFAAIAACHg");
	this.shape_59.setTransform(14.325,-7.625);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#1690BF").s().p("AiQBJICRiRICQAAIAACRg");
	this.shape_60.setTransform(15.525,-8.275);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#1690BF").s().p("AiXBNICYiYICXAAIAACYg");
	this.shape_61.setTransform(16.25,-8.65);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#1690BF").s().p("AiZBOICaibICZAAIAACbg");
	this.shape_62.setTransform(16.475,-8.775);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_54}]},3).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58}]},1).to({state:[{t:this.shape_59}]},1).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_61}]},1).to({state:[{t:this.shape_62}]},1).to({state:[{t:this.shape_62}]},8).to({state:[]},1).wait(352));

	// yellow_bottom
	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#FDB61B").s().p("AgFALIAAgVIAKAKIAAALg");
	this.shape_63.setTransform(0.65,1.2);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#FDB61B").s().p("AgWAtIAAhZIAsAsIAAAtg");
	this.shape_64.setTransform(2.55,4.775);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#FDB61B").s().p("AgkBKIAAiTIBJBKIAABJg");
	this.shape_65.setTransform(4.225,7.875);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#FDB61B").s().p("AgwBiIAAjDIBiBiIAABhg");
	this.shape_66.setTransform(5.65,10.5);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#FDB61B").s().p("Ag7B2IAAjrIB3B2IAAB1g");
	this.shape_67.setTransform(6.775,12.625);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#FDB61B").s().p("AhDCGIAAkLICHCHIAACEg");
	this.shape_68.setTransform(7.675,14.3);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#FDB61B").s().p("AhICRIAAkhICRCSIAACPg");
	this.shape_69.setTransform(8.325,15.5);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#FDB61B").s().p("AhLCYIAAkvICYCYIAACXg");
	this.shape_70.setTransform(8.7,16.225);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#FDB61B").s().p("AhNCaIAAkzICbCaIAACZg");
	this.shape_71.setTransform(8.825,16.45);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_63}]},2).to({state:[{t:this.shape_64}]},1).to({state:[{t:this.shape_65}]},1).to({state:[{t:this.shape_66}]},1).to({state:[{t:this.shape_67}]},1).to({state:[{t:this.shape_68}]},1).to({state:[{t:this.shape_69}]},1).to({state:[{t:this.shape_70}]},1).to({state:[{t:this.shape_71}]},1).to({state:[{t:this.shape_71}]},9).to({state:[]},1).wait(352));

	// Registration
	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("rgba(27,68,157,0.667)").s().p("AgNAOQgGgFAAgJQAAgHAGgHQAGgFAHAAQAIAAAGAFQAGAHAAAHQAAAJgGAFQgGAGgIAAQgHAAgGgGgAgLgLQgEAFAAAGQAAAHAEAFQAFAFAGAAQAHAAAFgFQAEgFgEgSQgCgCgGAAQgFAAgKACgAAAABIgDAKIgEAAIAAgVIAIAAIAJAVg");
	this.shape_72.setTransform(3.075,35.85);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("rgba(27,68,157,0.722)").s().p("AgNAOQgGgFAAgJQAAgHAGgHQAGgFAHAAQAIAAAGAFQAGAHAAAHQAAAJgGAFQgGAGgIAAQgHAAgGgGgAgLgLQgEAFAAAGQAAAHAEAFQAFAFAGAAQAHAAAFgFQADgEgDgTQgCgBgGAAIgPABgAgGALIgBgBIAAgUIAHAAIAAAAIgGAAIAAAQIAAAEIADAAIAAABIgDAAgAgDAKgAgCAFIACgCIAAgBIgBADIgCAFg");
	this.shape_73.setTransform(3.075,35.85);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("rgba(27,68,157,0.776)").s().p("AgNAOQgGgFAAgJQAAgHAGgHQAGgFAHAAQAIAAAGAFQAGAHAAAHQAAAJgGAFQgGAGgIAAQgHAAgGgGgAgLgLQgEAFAAAGQAAAHAEAFQAFAFAGAAQAHAAAFgFQADgEgEgTQgBgBgGAAIgPABgAgGALIgBgBIAAgUIAIAAIAEAKIgFgJIgGAAIAAANIABADIADAAIgBADIgCABgAAGAJIgGgHIgBACIgBADIAAgCIABgBIACgDIAGADIACAHgAgCAHg");
	this.shape_74.setTransform(3.075,35.85);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("rgba(27,68,157,0.835)").s().p("AgNAOQgGgFAAgJQAAgHAGgHQAGgFAHAAQAIAAAGAFQAGAHAAAHQAAAJgGAFQgGAGgIAAQgHAAgGgGgAgLgLQgEAFAAAGQAAAHAEAFQAFAFAGAAQAHAAAFgFQADgEgEgTQgBgCgGAAIgPACgAgFALIgCgBIAAgUIAIAAIADAHIgEgGIgFAAIAAAMIABACIACAAIgBAFIgCABgAAGAKIgGgIIAAAAIgBABIABgBIACgCIAEACIADAIg");
	this.shape_75.setTransform(3.075,35.85);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("rgba(27,68,157,0.89)").s().p("AgNAOQgGgFAAgJQAAgHAGgHQAGgFAHAAQAIAAAGAFQAGAHAAAHQAAAJgGAFQgGAGgIAAQgHAAgGgGgAgLgLQgEAFAAAGQAAAHAEAFQAFAFAGAAQAHAAAFgFQAEgFgFgTQgBgBgFAAQgFAAgLACgAgFALIgCAAIAAgVIAIAAIACAGIgDgEIgEAAIAAAJIABACIAAAAIAAAGIgBACgAAGAKIgGgHIAAgBIgBAAIABgBIACgBIADAAIAEAKg");
	this.shape_76.setTransform(3.075,35.85);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("rgba(27,68,157,0.945)").s().p("AgNAOQgGgFAAgJQAAgHAGgHQAGgFAHAAQAIAAAGAFQAGAHAAAHQAAAJgGAFQgGAGgIAAQgHAAgGgGgAgLgLQgEAFAAAGQAAAHAEAFQAFAFAGAAQAHAAAFgFQAEgFgFgTQgCgBgFAAQgFAAgKACgAgEALIgDAAIAAgVIAIAAIADAFIgEgDIgEAAIAAAIIACABIABAAIABgBIADAAIACAAIAEAKIgDABIgFgIIgBgBIgDAAIgBAJg");
	this.shape_77.setTransform(3.075,35.85);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#1B449D").s().p("AgNAOQgGgFAAgJQAAgHAGgHQAGgFAHAAQAIAAAGAFQAGAHAAAHQAAAJgGAFQgGAGgIAAQgHAAgGgGgAgLgLQgEAFAAAGQAAAHAEAFQAFAFAGAAQAHAAAFgFQAEgFAAgHQAAgGgEgFQgFgEgHAAQgGAAgFAEgAAGALIgGgKIgDAAIAAAKIgEAAIAAgVIAIAAQAIgBAAAHQAAAEgGABIAHAKgAgDAAIADAAQAGAAAAgEQAAgDgFAAIgEAAg");
	this.shape_78.setTransform(3.075,35.85);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_72}]},13).to({state:[{t:this.shape_73}]},1).to({state:[{t:this.shape_74}]},1).to({state:[{t:this.shape_75}]},1).to({state:[{t:this.shape_76}]},1).to({state:[{t:this.shape_77}]},1).to({state:[{t:this.shape_78}]},1).to({state:[]},1).wait(352));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-53.4,-46.1,106.5,92.30000000000001);


(lib.image_05 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#008FBE").s().p("A3bfQMAAAg+fMAu3AAAMAAAA+fg");
	this.shape.setTransform(0,3.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer_1
	this.instance = new lib.Image_01();
	this.instance.setTransform(-150,-196.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.image_05, new cjs.Rectangle(-150,-196.9,300,399.9), null);


(lib.image_04 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Image_04();
	this.instance.setTransform(-150,-196.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.image_04, new cjs.Rectangle(-150,-196.5,300,376), null);


(lib.image_03 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Image_03();
	this.instance.setTransform(-150,-196.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.image_03, new cjs.Rectangle(-150,-196.5,300,376), null);


(lib.image_02 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Image_02();
	this.instance.setTransform(-150,-196.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.image_02, new cjs.Rectangle(-150,-196.5,300,376), null);


(lib.image_01 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Image_01();
	this.instance.setTransform(-150,-196.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.image_01, new cjs.Rectangle(-150,-196.5,300,393), null);


(lib.ctaBtn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// TALK_TO_US_TODAY
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#A8A8A8").s().p("AgDAyQgHgDgGgFQgGgGgCgHQgEgIAAgKIAAg9IAZAAIAAA9QABAIADAFQAEAFAIAAQAHAAAFgFQAEgFABgIIAAg9IAZAAIAAA9QgBAKgDAIQgDAHgFAGQgFAFgIADQgHACgKAAQgJAAgHgCgAiDAxQgKgFgHgHQgHgHgEgJQgEgKAAgLQAAgKAEgKQAEgJAHgHQAHgIAKgEQAJgDALAAQALAAAJADQAKAEAHAIQAHAHAEAJQAFAKAAAKQAAALgFAKQgEAJgHAHQgHAHgKAFQgJADgLAAQgLAAgJgDgAh6gaQgFADgDAEQgEADgDAGQgCAFAAAFQAAAGACAFQACAFAEAEQAEAEAFACQAFADAGAAQAGAAAFgDQAGgCADgEIAGgJQACgFAAgGQAAgFgCgFQgDgGgDgDQgEgEgFgDQgFgCgGAAQgGAAgFACgAIvAzIAAgrIghg6IAaAAIATAlIAUglIAaAAIgiA6IAAArgAHYAzIAAgnIghAAIAAAnIgYAAIAAhlIAYAAIAAAmIAhAAIAAgmIAZAAIAABlgAFMAzIgSg/IgRA/IgYAAIgchlIAYAAIAQA+IASg+IAXAAIASA+IAQg+IAYAAIgcBlgAByAzIAAhPIgcAAIAAgWIBQAAIAAAWIgcAAIAABPgAlNAzIAAhlIAlAAQALAAALADQAJAEAIAHQAGAHAEAJQAEAKAAAKQAAALgEAJQgEAKgHAGQgHAHgJAEQgLAEgLAAgAk0AcIALAAQAHAAAFgCQAFgCAFgEQADgEACgFQADgFAAgGQAAgFgDgGQgCgFgDgEQgEgDgFgDQgGgCgIAAIgKAAgAmGAzIgog/IAAA/IgYAAIAAhlIAaAAIAmA8IAAg8IAYAAIAABlgAoAAzIAAhlIAYAAIAABlgApoAzIAAhlIBHAAIAAAXIguAAIAAASIAuAAIAAAWIguAAIAAAmg");
	this.shape.setTransform(3.15,0.35);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer_3
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["rgba(201,201,198,0.298)","rgba(201,201,198,0)"],[0,0.608],-53.5,0,68.2,0).s().p("AnICpIFLlRIJGAAIAAFRg");
	this.shape_1.setTransform(33.025,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	// _Path__1
	this.instance = new lib.Bitmap1();
	this.instance.setTransform(-89,-33,0.7554,0.8156);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ctaBtn, new cjs.Rectangle(-89,-33,194.9,78.3), null);


(lib.bswh_logo = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.BSWH_Icon("synched",0,false);
	this.instance.setTransform(1.2,-43.3,0.7829,0.7829,-44.2419,0,0,0.1,0.1);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({regX:0.2,scaleX:0.7828,scaleY:0.7828,rotation:-0.7885,x:1.3,y:-43.35,startPosition:6},6,cjs.Ease.quadOut).to({regX:0.1,scaleX:0.7829,scaleY:0.7829,rotation:0,x:1.25,y:-43.25,mode:"single",startPosition:19},13).wait(1).to({startPosition:19},0).to({_off:true},1).wait(99));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#1790BE").s().p("Ai1AZQgIgKgBgPQABgOAIgKQAKgKAOAAQAMAAAIAGQAJAHAAALIgNAAQgBgFgFgDQgDgEgHAAQgGAAgEAEQgFADgBAFQgCAFAAAFQABAKAEAGQAEAHAJAAQAIAAADgEQAEgFABgGIAOAAQgBAMgIAIQgIAHgNAAQgOAAgKgKgADxAiIAAgaIgZgoIARAAIAPAaIAQgaIARAAIgZAoIAAAagACbAiIAAhCIAyAAIAAAMIgjAAIAAAOIAgAAIAAALIggAAIAAAQIAkAAIAAANgAB4AiIgcgsIAAAAIAAAsIgPAAIAAhCIAQAAIAcAsIAAgsIAOAAIAABCgAAqAiIgcgsIAAAsIgNAAIAAhCIAOAAIAcAsIAAAAIAAgsIAOAAIAABCgAgiAiIAAhCIAPAAIAABCgAhCAiIgUgfIgJAJIAAAWIgOAAIAAhCIAOAAIAAAbIAbgbIASAAIgaAaIAdAogAjdAiIAAgvIgRAvIgLAAIgQgvIgBAAIAAAvIgOAAIAAhCIAWAAIAQAtIAOgtIAVAAIAABCg");
	this.shape.setTransform(1.45,59.725);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#1B449E").s().p("ABmDmQgMgOAAgVQAAgVAMgOQANgOAVAAQAPAAAMAJQALAJACAPIgUAAQgBgGgGgFQgFgFgIAAQgJAAgGAFQgGAEgCAIQgDAHAAAIQAAANAGAJQAHAJANAAQAJAAAFgFQAGgGABgKIAUAAQgBASgMAKQgLALgRAAQgVAAgNgOgAj6DmQgNgOAAgVQAAgVANgOQAMgOAVAAQAQAAAMAJQALAJACAPIgUAAQgBgGgGgFQgGgFgIAAQgJAAgFAFQgGAEgDAIQgCAGAAAJQAAANAGAJQAHAJAMAAQAJAAAGgFQAGgHAAgJIAUAAQgBASgLAKQgLALgSAAQgVAAgMgOgAKXDyIgBgHIgBgJIgBgHQgBgHgDgEQgEgDgHAAIgVAAIAAAlIgVAAIAAheIAzAAQAMAAAIAIQAHAHAAALQAAARgPAGQANAEABASIABAOIABAFIACAEgAJwC+IAWAAQAPAAAAgNQAAgNgPAAIgWAAgAH5DyIAAheIBGAAIAAARIgxAAIAAAUIAtAAIAAAQIgtAAIAAAXIAyAAIAAASgAGxDyIAAhNIgcAAIAAgRIBMAAIAAARIgcAAIAABNgAFoDyIgng/IAAA/IgTAAIAAheIAUAAIAoA/IAAg/IATAAIAABegADMDyIAAheIBGAAIAAARIgxAAIAAAUIAtAAIAAAQIgtAAIAAAXIAyAAIAAASgAguDyIAAheIAVAAIAABMIAtAAIAAASgAhYDyIgHgVIgjAAIgIAVIgVAAIAkheIAVAAIAjBegAh9DNIAYAAIgLgiIgBAAgAk3DyIAAheIAVAAIAABegAmlDyIAAheIApAAQATAAAMAMQALAMAAAWQAAAVgLANQgKAOgVAAgAmQDgIASAAQAKAAAHgHQAHgGAAgPQAAgPgHgIQgGgIgOAAIgPAAgAoHDyIAAheIBGAAIAAARIgxAAIAAAUIAtAAIAAAQIgtAAIAAAXIAyAAIAAASgAo5DyIAAhDIgXBDIgQAAIgXhCIAABCIgUAAIAAheIAdAAIAWBAIABAAIAUhAIAdAAIAABegAuuBnQgEgFAAgHQAAgHAEgEQAEgEAHAAIAHAAQAIAAAEgGQANgTAFgPQAEgJAAgHQAAgIgGgRIgdhPQgGgQgDgEQgEgHgJgCIgJgCQgCgBABgEQAAgBAAAAQAAgBAAgBQABAAAAgBQAAAAABAAIAjABIAggBQACABABADQAAAEgCABIgJACQgIACAAADQAAAEAKAeIAMAjIAGAPIAFALQACgBAMgbIAMgdQANgfAAgGQAAgFgJgBIgLgCQgCgBAAgEQAAgDADgBIA8AAQADABAAADQAAADgCACIgGABQgJACgHAJQgFAHgLAWIgUAqQgbA2gfBEQgIARgQAAQgIAAgEgEgAK5AbQgHgVgQgiIgWgyQgiBGgMAjIgFABIgFgBQgLgbgPggQguhngZgzQgGgOgEgFQgGgHgKgBIgJgBQgCgCAAgDQAAgBAAAAQABgBAAAAQAAgBABAAQAAgBABAAIAmABIAqgBQAAAAABABQAAAAABAAQAAABAAAAQAAABAAABQABADgCACIgJABQgMABAAAFQAAAFATAtIBACKIAdg8IAGgPQAAgDgDgHQgVgwgUgpQgEgJgFgFQgGgFgIgBIgJgBQgCgCAAgDQAAgBAAAAQABgBAAAAQAAgBAAAAQABgBAAAAIAoABIApgBQAAAAABABQAAAAAAAAQABABAAAAQAAABAAABQAAADgBACIgKABQgLABgBADQgBAEAFAMIAdBBIAWgxQAJgXAAgGQAAgHgKAAIgLgBQgCgDABgCQAAgBAAgBQAAAAAAgBQABAAAAAAQAAgBABAAIAjABIAjgBQABAAAAABQABAAAAAAQAAABAAAAQABABAAABQAAADgCACIgLABQgKABgIAKIgMAWQgPAbgOAgQgDAGAAADQAAADACAGIAmBUIAhhOQAVgxAJgZQALgeAAgEQAAgIgMAAIgLgBQgCgCAAgDQAAgBAAgBQABAAAAgBQAAAAABAAQAAgBABAAIAjABIABAAIADAAQARAAALgHQAHgEAMgJIACAAQAAAAABAAQAAAAAAABQAAAAAAAAQAAAAAAABIgBAuIAABOQAAAGACABQAZgTAZAAQAYAAANAOQALAMAAAWIAAA9QAAAUACAFQACAGAKABIAKABQACABgBAEQAAABAAAAQAAABAAAAQgBABAAAAQAAABgBAAQgSgBgTAAQgVAAgOABQAAAAgBgBQAAAAAAgBQAAAAgBgBQAAAAAAgBQAAgDACgCIAHgBQAKgCACgFQACgFAAgUIAAg1QAAgSgIgKQgKgLgRAAQgRAAgMAKQgFAEgBADQgCAEAAAJIAAA+QAAAUACAFQADAGAJABIAIABQACABAAAEQgBADgCABQgPgBgUAAQgUAAgQABQgCgBAAgDQAAgEABgBIAKgBQAKgBACgGQACgFAAgUIAAinQAAgRgCgFQgBgDgDAAQgHADgFAIQgFAIgTArIgbA/QgYA4gWA5IgFABIgFgBgAmiAOQgDgGgDgPQgDgQgBgOQACgCADAAQABAAABAAQAAAAABAAQAAAAABABQAAAAAAAAQAGAWAMANQASATAcAAQAWAAANgNQAMgKAAgSQAAgPgFgLQgHgOgTgMIgjgXQgogbAAglQAAgbAUgSQAVgTAiAAQASAAARAFQAHACAGAAQADAIABAMQADAOAAAMQgBAAAAAAQgBABAAAAQgBAAAAAAQgBAAgBABQgDAAgCgBQgFgTgIgJQgNgOgYAAQgZAAgLAOQgIALAAAQQAAAaAfAUIAeASQAuAdAAAqQAAAfgVASQgWATgkAAQgiAAgYgOgAS8AUQgNgGgJgLQgQgUAAgcQAAgiAVgYQAVgZAhAAQAXAAAPANQAPANAAASQAAAHgCADQgBACgVAAIhEAAQgIAAgBACQgBABAAAHQAAAdAQAUQARAUAcAAQAKAAAIgEQAIgDAIgLQADgBACACQABAAAAAAQAAABAAAAQABABAAAAQAAABAAABQgIAQgSAKQgQAHgQAAQgSAAgOgHgATAhqQgMALAAAKQAAAAAAABQAAAAAAAAQABAAAAABQABAAAAAAIAbAAQAhAAAFgEQADgBAAgGQAAgJgHgGQgHgIgPAAQgQAAgNALgARJAQQgIgKAAgSIAAhVIAAgJQgCgBgFAAIgLAAIgCgEIABgEQAQgFAIgHQAIgHAIgPQAFgCACAEIAAARQAAAFABABQABABAFAAIApAAQADACAAAGQAAAGgCACIgqAAQgFAAgBABQgBABAAAHIAABFQAAAUAEAIQAGAMARAAQAGAAAEgCIAJgFQABAAAAAAQABAAAAAAQABABAAAAQAAABABAAQAAABAAAAQAAABAAAAQAAABAAAAQAAABAAAAQgGAHgJAFQgLAFgNAAQgWAAgJgLgAC+AQQgHgKAAgSIAAhVIgBgJQgBgBgGAAIgKAAIgCgEIABgEQAQgFAHgHQAJgHAHgPQAGgCACAEIAAARQAAAFABABQABABAFAAIApAAQADACAAAGQAAAGgDACIgqAAQgEAAgCABQgBABAAAHIAABFQAAAUAFAIQAGAMARAAQAFAAAEgCIAKgFQAAAAABAAQAAAAABAAQAAABABAAQAAABAAAAQABABAAAAQAAABAAAAQAAABAAAAQAAABgBAAQgFAHgJAFQgMAFgMAAQgWAAgKgLgABOAQQgHgKAAgSIAAhVQAAgHgBgCQgBgBgGAAIgKAAQgBgBAAAAQAAgBAAAAQgBgBAAAAQAAgBAAAAQAAgBAAgBQAAAAAAgBQAAAAAAgBQAAAAABAAQAQgFAHgHQAJgHAHgPQAGgCACAEIAAARQAAAFABABQABABAFAAIApAAQADACAAAGQAAAGgDACIgqAAQgFAAgBABIAAAIIAABFQAAAUAEAIQAGAMAQAAQAGAAAFgCIAJgFQAAAAABAAQAAAAABAAQAAABABAAQAAABAAAAQABABAAAAQAAABAAAAQAAABAAAAQAAABgBAAQgOARgYAAQgXAAgJgLgAhhAHQgWgVAAgiQAAgjAXgXQAXgWAhAAQAgAAAUAVQAXAWAAAhQAAAkgWAVQgVAWgjAAQggAAgWgUgAhLhkQgMARAAAeQAAAcAMAUQANAVAXAAQAXAAALgUQAIgQAAgZQAAgdgKgTQgNgYgYAAQgTAAgMARgAjsAIQgVgTAAgiQAAgiAWgXQAYgaArAAQATAAAOAGQAGAFAAAKQAAAFgCAEQgDAEgDAAQgDAAgDgCQgGgIgJgGQgLgGgLAAQgUAAgPAPQgQARAAAcQAAAYAPATQARAUAcAAQAPAAALgHQAIgEAHgLQABAAAAAAQABAAABAAQAAAAAAAAQABABAAAAQABAAAAABQABAAAAABQAAAAABABQAAABAAAAQgJASgTALQgQAIgSAAQggAAgTgTgAq3AHQgWgVAAgiQAAgjAXgXQAXgWAhAAQAfAAAWAVQAWAWAAAhQAAAkgWAVQgWAWgiAAQghAAgVgUgAqhhkQgMARAAAeQAAAcAMAUQANAVAXAAQAWAAALgUQAJgQAAgZQAAgdgKgTQgNgYgZAAQgSAAgMARgAvpAQQgEgFgCAAIgPAHIgMAGQgIADgGAAQgQAAgKgIQgMgKAAgPQAAgLAHgHQAHgHARgHIAsgQQAEgBABgDIABgHIABgRQAAgMgFgJQgHgLgPAAQgJAAgHAEQgIAFAAAIQgBAKgDACQgEADgGADIgLABQgFAAAAgFQAAgOAYgQQAYgPAVAAQAUAAAKALQAJALAAAVIgDBBQgBAfASAAQAFAAAFgCIAEgDQADAAAAAFQAAADgJAGQgKAHgMAAQgPAAgJgLgAwBgmQgSAGgGAFQgIAGAAAKQAAAHAFAGQAGAJAMAAQAFAAAIgDQAHgEADgDQADgCABgEIABgKIAAgWQAAgFgDAAQgFAAgLAEgAE9AGQgXgSAAgcQAAgpArgSQgPgQAAgQQAAgUAOgNQANgNAUAAQANAAAKAHQALAIAAAMQAAANgKAHQgIAGgHAAQgIAAAFgGQAGgIgDgIQgCgGgFgEQgFgEgIAAQgKgBgHAGQgHAGAAAJQAAAJAHAHQAHAHASAKQAhASANAMQAYAUAQAhQAMgPAAgUQAAgOgIgLQgFgGgIgBQgLgBgIAGQgCACgDgBQgDgBABgHQABgJAJgGQAJgHAOAAQAHAAAMACIAOACQAGAAADgDIACgCQADAAABADQAAAUgZAHQAFALAAANQAAAZgUAXQAIAOAJAHQAJAGAOAAQAGAAADgBIAHgCQAAAAABAAQAAAAAAABQABAAAAABQAAAAAAABQAAAFgKADQgLAEgPAAQgOAAgJgEQgJgEgNgLQgSALgOAEQgNAEgQAAQgiAAgXgTgAFDg+QAAAdAUAVQAVAVAbAAQAKAAAHgCIAUgHQgJgKgHgMIgIgLQgOgUgOgOQgJgIgOgLIgIgGQgWAFAAAZgAP9AWQgVAAgOABQgBAAAAgBQAAAAAAgBQgBAAAAgBQAAAAAAgBQgBgEACgBIAIgBQAKgBACgGQACgFAAgUIAAhAQAAgMgBgDQgCgEgHgFIgDgCIgBgDQAAgBAAAAQAAgBAAAAQAAgBABAAQAAAAAAAAIATgIIATgKQABAAABAAQABAAAAAAQABAAAAABQAAAAAAABQgBAVAAAZIAABCQAAAUACAFQACAGAKABIAIABQABABAAAEQAAADgCABQgPgBgUAAgAn9AWQgVAAgNABQgCgBgBgDQAAgDACgCIAHgBQAKgCACgFQACgFAAgUIAAhAQAAgMgBgDQgBgEgIgFIgDgCIgBgDIABgDIATgIIATgKQABAAAAAAQABAAAAABQAAAAABAAQAAABAAAAIAAAWIABADIAUgPQALgHAKAAQAHAAAEAEQAFAEAAAHQAAAIgGAFQgEAEgGAAQgDAAgFgDQgIgGgIAAQgIAAgGAHQgEAHAAAWIAAAyQAAAUACAFQACAGALABIANABQACABgBAEQAAABAAAAQAAABAAAAQAAABgBAAQAAABgBAAIgpgBgAr+AWQgVAAgPABQAAAAgBgBQAAAAAAgBQAAAAgBgBQAAAAAAgBQAAgEACgBIAIgBQAKgBACgGQACgFAAgUIAAinQAAgRgBgEQgCgFgIgFIgEgCQAAAAAAgBQgBAAAAgBQAAAAAAgBQAAAAAAgBQAAgBAAAAQAAgBAAAAQAAgBABAAQAAAAAAAAQAcgKAMgGQABAAAAAAQABAAAAAAQABAAAAABQAAAAABABIgBAuIAACvQAAAUACAFQACAGAKABIAJABQACACgBADQAAADgCABQgQgBgUAAgAzlAWIgrABQAAAAAAgBQgBAAAAgBQAAAAAAgBQgBAAAAgBQAAgDACgCIAGgBQAPgDADgHQADgGAAgeIAAiMQAAgWgDgGQgDgHgMgBIgMgCQgCgBAAgEQAAgBAAAAQAAgBABAAQAAgBAAAAQAAgBABAAQAegDAyAAQAqAAAUAKQAcAPAAAgQAAATgKAMQgJALgTAJQAAAAAAABQABAAAAABQAAAAAAABQABAAAAABIAGABQASAEAOAOQARARAAAbQAAAhgYASQgaAUgwAAIgtgBgAzUhlQgDACAAAGIAAA3QAAAfAIAIQAIALAVAAQAbAAAPgMQAQgNAAgaQAAgbgOgQQgTgVgoAAQgPAAgEACgAzSjRIgEADIgBAGIAABMQAAAIADABQADACANgBQAegBAOgKQAPgLAAgZQAAgagRgNQgPgLgYAAQgMAAgFACgAPtikQgGgFAAgHQAAgJAGgGQAGgGAJAAQAIAAAFAGQAFAGAAAIQAAAJgGAFQgFAFgJAAQgIAAgFgGg");
	this.shape_1.setTransform(-0.33,19.7875);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_1},{t:this.shape}]},20).to({state:[]},1).wait(99));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-130.5,-79.6,260.4,142.89999999999998);


// stage content:
(lib.BSWH_CancerHatesUs_V3_300x600 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = false; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// border
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,1,1).p("Aq7x4IV3AAMAAAAjxI13AAg");
	this.shape.setTransform(149.9939,299.9778,2.1429,2.6207);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(355));

	// BSWH_Logo
	this.instance = new lib.bswh_logo("synched",0,false);
	this.instance.setTransform(149.2,466.5);
	this.instance.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({alpha:1,mode:"single",startPosition:20},20).wait(335));

	// cta_btn
	this.instance_1 = new lib.ctaBtn();
	this.instance_1.setTransform(148,595.4);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(319).to({_off:false},0).wait(1).to({regX:8.5,regY:6.2,x:156.5,y:596.95,alpha:0.1786},0).wait(1).to({y:592.35,alpha:0.3564},0).wait(1).to({y:588,alpha:0.5237},0).wait(1).to({y:584.1,alpha:0.6735},0).wait(1).to({y:580.75,alpha:0.8027},0).wait(1).to({y:577.95,alpha:0.911},0).wait(1).to({regX:0,regY:0,x:148,y:569.45,alpha:1},0).wait(1).to({regX:8.5,regY:6.2,x:156.5,y:573.55},0).wait(1).to({y:571.9},0).wait(1).to({y:570.6},0).wait(1).to({y:569.65},0).wait(1).to({y:569},0).wait(1).to({regX:0,regY:0,x:148,y:562.4},0).wait(23));

	// image_mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_275 = new cjs.Graphics().p("A1PcSMAAAg4jMAqfAAAMAAAA4jg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(275).to({graphics:mask_graphics_275,x:149,y:194.05}).wait(80));

	// safeCare_logo
	this.instance_2 = new lib.safeCare_logo();
	this.instance_2.setTransform(183.7,98.05,3.3814,3.3814,5.4832,0,0,0.1,0.1);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(302).to({_off:false},0).to({regX:0,scaleX:1.3334,scaleY:1.3334,rotation:0,x:183.35,alpha:1},9,cjs.Ease.quadOut).to({scaleX:1.5457,scaleY:1.5457,y:98},15,cjs.Ease.quadOut).wait(29));

	// txt_cancerHatesUs
	this.instance_3 = new lib.txt_cancerHatesUs();
	this.instance_3.setTransform(127.2,-51.85);
	this.instance_3._off = true;

	var maskedShapeInstanceList = [this.instance_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(285).to({_off:false},0).to({y:328.3},26,cjs.Ease.quadOut).wait(44));

	// image_05
	this.instance_4 = new lib.image_05();
	this.instance_4.setTransform(150.2,-207.3);
	this.instance_4._off = true;

	var maskedShapeInstanceList = [this.instance_4];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(275).to({_off:false},0).wait(2).to({y:-202.9},0).wait(1).to({regY:3,y:-103.45},0).wait(1).to({y:-39.7},0).wait(1).to({y:6.5},0).wait(1).to({y:41.8},0).wait(1).to({y:69.6},0).wait(1).to({y:91.95},0).wait(1).to({y:110.15},0).wait(1).to({y:125.2},0).wait(1).to({y:137.7},0).wait(1).to({y:148.1},0).wait(1).to({y:156.9},0).wait(1).to({y:164.25},0).wait(1).to({y:170.5},0).wait(1).to({y:175.75},0).wait(1).to({y:180.15},0).wait(1).to({y:183.9},0).wait(1).to({y:187},0).wait(1).to({y:189.65},0).wait(1).to({y:191.8},0).wait(1).to({y:193.6},0).wait(1).to({y:195.1},0).wait(1).to({y:196.3},0).wait(1).to({y:197.25},0).wait(1).to({y:198.05},0).wait(1).to({y:198.65},0).wait(1).to({y:199.1},0).wait(1).to({y:199.45},0).wait(1).to({y:199.7},0).wait(1).to({y:199.85},0).wait(1).to({y:199.95},0).wait(1).to({y:200.05},0).wait(3).to({regY:0,y:197.1},0).wait(44));

	// image_mask (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_207 = new cjs.Graphics().p("A1PcSMAAAg4jMAqfAAAMAAAA4jg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(207).to({graphics:mask_1_graphics_207,x:149,y:194.05}).wait(148));

	// CC_Logo
	this.instance_5 = new lib.CC_Logo();
	this.instance_5.setTransform(111.25,321.8,0.6142,0.6142,0,0,0,0.1,0.1);
	this.instance_5.alpha = 0;
	this.instance_5._off = true;

	var maskedShapeInstanceList = [this.instance_5];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(232).to({_off:false},0).to({alpha:1},11).wait(112));

	// txt_qualityCare
	this.instance_6 = new lib.txt_qualityCare();
	this.instance_6.setTransform(127.2,-51.85);
	this.instance_6._off = true;

	var maskedShapeInstanceList = [this.instance_6];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(217).to({_off:false},0).to({y:62.65},26,cjs.Ease.quadOut).wait(112));

	// image_04
	this.instance_7 = new lib.image_04();
	this.instance_7.setTransform(150.2,-185.3);
	this.instance_7._off = true;

	var maskedShapeInstanceList = [this.instance_7];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(207).to({_off:false},0).wait(3).to({regY:-8.5,y:-101.6},0).wait(1).to({y:-40.65},0).wait(1).to({y:3.55},0).wait(1).to({y:37.3},0).wait(1).to({y:63.85},0).wait(1).to({y:85.2},0).wait(1).to({y:102.6},0).wait(1).to({y:117},0).wait(1).to({y:128.9},0).wait(1).to({y:138.9},0).wait(1).to({y:147.3},0).wait(1).to({y:154.35},0).wait(1).to({y:160.3},0).wait(1).to({y:165.3},0).wait(1).to({y:169.55},0).wait(1).to({y:173.1},0).wait(1).to({y:176.1},0).wait(1).to({y:178.6},0).wait(1).to({y:180.65},0).wait(1).to({y:182.4},0).wait(1).to({y:183.8},0).wait(1).to({y:184.95},0).wait(1).to({y:185.9},0).wait(1).to({y:186.6},0).wait(1).to({y:187.2},0).wait(1).to({y:187.65},0).wait(1).to({y:187.95},0).wait(1).to({y:188.2},0).wait(1).to({y:188.35},0).wait(1).to({y:188.45},0).wait(1).to({y:188.55},0).wait(3).to({regY:0,y:197.1},0).wait(112));

	// image_mask (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_142 = new cjs.Graphics().p("A1PcSMAAAg4jMAqfAAAMAAAA4jg");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:null,x:0,y:0}).wait(142).to({graphics:mask_2_graphics_142,x:149,y:194.05}).wait(213));

	// txt_advancedTreatment
	this.instance_8 = new lib.txt_advancedTreatment();
	this.instance_8.setTransform(127.2,-51.85);
	this.instance_8._off = true;

	var maskedShapeInstanceList = [this.instance_8];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(152).to({_off:false},0).to({y:62.65},26,cjs.Ease.quadOut).wait(177));

	// image_03
	this.instance_9 = new lib.image_03();
	this.instance_9.setTransform(150.2,-185.3);
	this.instance_9._off = true;

	var maskedShapeInstanceList = [this.instance_9];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(142).to({_off:false},0).wait(3).to({regY:-8.5,y:-101.6},0).wait(1).to({y:-40.65},0).wait(1).to({y:3.55},0).wait(1).to({y:37.3},0).wait(1).to({y:63.85},0).wait(1).to({y:85.2},0).wait(1).to({y:102.6},0).wait(1).to({y:117},0).wait(1).to({y:128.9},0).wait(1).to({y:138.9},0).wait(1).to({y:147.3},0).wait(1).to({y:154.35},0).wait(1).to({y:160.3},0).wait(1).to({y:165.3},0).wait(1).to({y:169.55},0).wait(1).to({y:173.1},0).wait(1).to({y:176.1},0).wait(1).to({y:178.6},0).wait(1).to({y:180.65},0).wait(1).to({y:182.4},0).wait(1).to({y:183.8},0).wait(1).to({y:184.95},0).wait(1).to({y:185.9},0).wait(1).to({y:186.6},0).wait(1).to({y:187.2},0).wait(1).to({y:187.65},0).wait(1).to({y:187.95},0).wait(1).to({y:188.2},0).wait(1).to({y:188.35},0).wait(1).to({y:188.45},0).wait(1).to({y:188.55},0).wait(3).to({regY:0,y:197.1},0).wait(177));

	// image_mask (mask)
	var mask_3 = new cjs.Shape();
	mask_3._off = true;
	var mask_3_graphics_77 = new cjs.Graphics().p("A1PcSMAAAg4jMAqfAAAMAAAA4jg");

	this.timeline.addTween(cjs.Tween.get(mask_3).to({graphics:null,x:0,y:0}).wait(77).to({graphics:mask_3_graphics_77,x:149,y:194.05}).wait(278));

	// txt_earlyDetection
	this.instance_10 = new lib.txt_earlyDetection();
	this.instance_10.setTransform(127.2,-51.85);
	this.instance_10._off = true;

	var maskedShapeInstanceList = [this.instance_10];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_3;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(87).to({_off:false},0).to({y:62.65},26,cjs.Ease.quadOut).wait(242));

	// image_02
	this.instance_11 = new lib.image_02();
	this.instance_11.setTransform(150.2,-185.3);
	this.instance_11._off = true;

	var maskedShapeInstanceList = [this.instance_11];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_3;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(77).to({_off:false},0).wait(3).to({regY:-8.5,y:-101.6},0).wait(1).to({y:-40.65},0).wait(1).to({y:3.55},0).wait(1).to({y:37.3},0).wait(1).to({y:63.85},0).wait(1).to({y:85.2},0).wait(1).to({y:102.6},0).wait(1).to({y:117},0).wait(1).to({y:128.9},0).wait(1).to({y:138.9},0).wait(1).to({y:147.3},0).wait(1).to({y:154.35},0).wait(1).to({y:160.3},0).wait(1).to({y:165.3},0).wait(1).to({y:169.55},0).wait(1).to({y:173.1},0).wait(1).to({y:176.1},0).wait(1).to({y:178.6},0).wait(1).to({y:180.65},0).wait(1).to({y:182.4},0).wait(1).to({y:183.8},0).wait(1).to({y:184.95},0).wait(1).to({y:185.9},0).wait(1).to({y:186.6},0).wait(1).to({y:187.2},0).wait(1).to({y:187.65},0).wait(1).to({y:187.95},0).wait(1).to({y:188.2},0).wait(1).to({y:188.35},0).wait(1).to({y:188.45},0).wait(1).to({y:188.55},0).wait(3).to({regY:0,y:197.1},0).wait(242));

	// image_mask (mask)
	var mask_4 = new cjs.Shape();
	mask_4._off = true;
	mask_4.graphics.p("A1PcSMAAAg4jMAqfAAAMAAAA4jg");
	mask_4.setTransform(149,194.05);

	// txt_cancerHatesFighters
	this.instance_12 = new lib.txt_cancerHatesFighters();
	this.instance_12.setTransform(127.2,-51.85);
	this.instance_12._off = true;

	var maskedShapeInstanceList = [this.instance_12];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_4;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(22).to({_off:false},0).to({y:62.65},26,cjs.Ease.quadOut).wait(307));

	// image_01
	this.instance_13 = new lib.image_01();
	this.instance_13.setTransform(150.2,-185.3);

	var maskedShapeInstanceList = [this.instance_13];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_4;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(15).to({y:-93.1125},0).wait(1).to({y:-32.1731},0).wait(1).to({y:12.056},0).wait(1).to({y:45.8022},0).wait(1).to({y:72.3641},0).wait(1).to({y:93.7154},0).wait(1).to({y:111.1357},0).wait(1).to({y:125.5031},0).wait(1).to({y:137.447},0).wait(1).to({y:147.4336},0).wait(1).to({y:155.8177},0).wait(1).to({y:162.8751},0).wait(1).to({y:168.8246},0).wait(1).to({y:173.8421},0).wait(1).to({y:178.0709},0).wait(1).to({y:181.6295},0).wait(1).to({y:184.6164},0).wait(1).to({y:187.1146},0).wait(1).to({y:189.1942},0).wait(1).to({y:190.9154},0).wait(1).to({y:192.3294},0).wait(1).to({y:193.4808},0).wait(1).to({y:194.4081},0).wait(1).to({y:195.1451},0).wait(1).to({y:195.7211},0).wait(1).to({y:196.1622},0).wait(1).to({y:196.491},0).wait(1).to({y:196.728},0).wait(1).to({y:196.891},0).wait(1).to({y:196.9961},0).wait(1).to({y:197.0574},0).wait(1).to({y:197.0877},0).wait(1).to({y:197.0985},0).wait(1).to({y:197.1},0).wait(307));

	// background
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape_1.setTransform(150,300);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(355));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(149,299,152,341.70000000000005);
// library properties:
lib.properties = {
	id: 'FC95E511C6C24CD7B72756EF013CB206',
	width: 300,
	height: 600,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"Bitmap1.png", id:"Bitmap1"},
		{src:"Image_01.jpg", id:"Image_01"},
		{src:"Image_02.jpg", id:"Image_02"},
		{src:"Image_03.jpg", id:"Image_03"},
		{src:"Image_04.jpg", id:"Image_04"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['FC95E511C6C24CD7B72756EF013CB206'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused){
			stageChild.syncStreamSounds();
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;